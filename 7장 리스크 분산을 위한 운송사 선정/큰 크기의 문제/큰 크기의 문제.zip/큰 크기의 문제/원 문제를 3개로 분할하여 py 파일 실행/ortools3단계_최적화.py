#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import pandas as pd
import os
import sys
import time
import math
from ortools.linear_solver import pywraplp

# 시작 시간 기록
start_time = time.time()

# 입력 파일 처리
if len(sys.argv) != 2:
    print("❗ 사용법: python 파일명.py 입력파일.xlsx")
    sys.exit(1)

input_file = sys.argv[1]
base_name = os.path.splitext(os.path.basename(input_file))[0]
file_path = input_file
df_excel = pd.ExcelFile(file_path)
# '기준정보' 시트가 있는지 확인하고 없으면 첫 시트 사용
if '기준정보' in df_excel.sheet_names:
    sheet_to_use = '기준정보'
    print("📄 '기준정보' 시트를 사용합니다.")
else:
    sheet_to_use = df_excel.sheet_names[0]
    print(f"📄 '기준정보' 시트가 없어 첫 번째 시트 '{sheet_to_use}'를 사용합니다.")
df = df_excel.parse(sheet_to_use)

# 데이터 정제
df_cleaned = df[['운송사', '운송구간', '트럭유형', '운송단가', '트럭대수', '운송구간.1', '트럭유형.1', '필요대수']]
df_cleaned.columns = ['운송사', '운송구간', '트럭유형', '운송단가', '트럭대수', '수요_운송구간', '수요_트럭유형', '필요대수']
df_demand = df_cleaned[['수요_운송구간', '수요_트럭유형', '필요대수']].drop_duplicates()
df_demand.columns = ['운송구간', '트럭유형', '필요대수']

max_trucker_num = int(df.iloc[0, 12])  # M2
max_ratio = float(df.iloc[0, 15])      # P2

def solve_optimization(sub_df, demand_df, max_trucker_num, max_ratio):
    demand_df = demand_df.dropna(subset=['필요대수'])
    cost_dict = {(r['운송사'], r['운송구간'], r['트럭유형']): r['운송단가'] for _, r in sub_df.iterrows()}
    capacity_dict = {(r['운송사'], r['운송구간'], r['트럭유형']): r['트럭대수'] for _, r in sub_df.iterrows()}
    demand_dict = {(r['운송구간'], r['트럭유형']): r['필요대수'] for _, r in demand_df.iterrows()}
    truckers = sub_df['운송사'].unique()
    route_type_list = demand_dict.keys()

    solver = pywraplp.Solver.CreateSolver('CBC')
    if not solver:
        print("❌ Solver 초기화 실패")
        return [], []

    x_vars = {k: solver.IntVar(0, capacity_dict[k], f"x_{k[0]}_{k[1]}_{k[2]}") for k in cost_dict}
    y_vars = {i: solver.BoolVar(f"y_{i}") for i in truckers}

    solver.Minimize(solver.Sum(cost_dict[k] * x_vars[k] for k in x_vars))

    for (r, t) in route_type_list:
        solver.Add(solver.Sum(x_vars[(i, r, t)] for i in truckers if (i, r, t) in x_vars) == demand_dict[(r, t)])

    for (i, r, t), cap in capacity_dict.items():
        solver.Add(x_vars[(i, r, t)] <= cap)

    for (i, r, t) in x_vars:
        solver.Add(x_vars[(i, r, t)] <= capacity_dict[(i, r, t)] * y_vars[i])

    solver.Add(solver.Sum(y_vars[i] for i in truckers) <= max_trucker_num)

    for (r, t), demand in demand_dict.items():
        x_max = math.ceil(demand * max_ratio)
        for i in truckers:
            if (i, r, t) in x_vars:
                solver.Add(x_vars[(i, r, t)] <= x_max)

    status = solver.Solve()

    if status not in [pywraplp.Solver.OPTIMAL, pywraplp.Solver.FEASIBLE]:
        print("❌ 해당 운송사 집합에서 유효한 해를 찾지 못했습니다.")
        return [], []

    result_data = [
        (i, r, t, cost_dict[(i, r, t)], int(x_vars[(i, r, t)].solution_value()))
        for (i, r, t) in x_vars if x_vars[(i, r, t)].solution_value() > 0
    ]
    selected_truckers = list({i for (i, _, _, _, _) in result_data})
    return result_data, selected_truckers

# 3단계 최적화 수행
all_truckers = df_cleaned['운송사'].unique()

df_a = df_cleaned[df_cleaned['운송사'].isin(all_truckers[:40])]
result_a, truckers_a = solve_optimization(df_a, df_demand, max_trucker_num, max_ratio)

df_b = df_cleaned[df_cleaned['운송사'].isin(all_truckers[40:80])]
result_b, truckers_b = solve_optimization(df_b, df_demand, max_trucker_num, max_ratio)

selected_truckers_ab = set(truckers_a + truckers_b)
df_c = df_cleaned[df_cleaned['운송사'].isin(list(selected_truckers_ab) + list(all_truckers[80:]))]
result_c, truckers_c = solve_optimization(df_c, df_demand, max_trucker_num, max_ratio)

if result_c:
    df_result = pd.DataFrame(result_c, columns=['운송사', '운송구간', '트럭유형', '운송단가', '선택된트럭수'])
    result_file = f"{base_name}_최적화결과.xlsx"
    df_result.to_excel(result_file, index=False)
    print(f"✅ 최적화 결과 저장 완료: {result_file}")
    print(df_result)
else:
    print("⚠️ 최종 단계에서도 유효한 해를 찾지 못했습니다.")

# 수행 시간 및 로그 저장
end_time = time.time()
elapsed_time = round(end_time - start_time, 4)
log_file = f"{base_name}__수행시간로그.txt"
with open(log_file, "w", encoding="utf-8") as f:
    f.write(f"{base_name}_수행시간: {elapsed_time}초\n")

print(f"\n프로그램 수행시간(초): {elapsed_time}")
print(f"로그 저장 파일: {log_file}")

