# -*- coding: utf-8 -*-
"""
월별 물류비 예측 모형 개발 (개정판)
- 모형: 다중회귀(LinearRegression), 라쏘(LassoCV), 의사결정나무(DecisionTreeRegressor)
- 종속변수: 물류비
- 독립변수: 1/2/3개월전 SCFI, 물동량, 월(원핫)   ※ 물류비 lag 제거
- 훈련: ~2025-08(실측 가용으로 2016-01부터 자동 조정)
- 테스트: 2025-09 ~ 2026-05
- 최종모델: 훈련+테스트 전체로 재적합하여 미래(2026-06~12) 예측
- 입력: 실행 위치 하위 raws 폴더 / 산출물: outputs/analysis 폴더
"""

import os
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

from sklearn.linear_model import LinearRegression, LassoCV
from sklearn.tree import DecisionTreeRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import mean_squared_error, r2_score

# ----------------------------------------------------------------------
# 0. 한글 폰트 설정
# ----------------------------------------------------------------------
def set_korean_font():
    for cand in ["NanumGothic", "Malgun Gothic", "AppleGothic", "Noto Sans CJK KR"]:
        try:
            fm.findfont(cand, fallback_to_default=False)
            plt.rcParams["font.family"] = cand
            break
        except Exception:
            continue
    else:
        path = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
        try:
            fm.fontManager.addfont(path)
            plt.rcParams["font.family"] = fm.FontProperties(fname=path).get_name()
        except Exception:
            pass
    plt.rcParams["axes.unicode_minus"] = False

set_korean_font()

# 입력 데이터는 실행 위치 하위의 raws 폴더에서 취합한다.
RAWS = "raws"
# 산출물은 실행 위치 하위의 outputs/analysis 폴더에 저장한다.
OUTPUT = os.path.join("outputs", "analysis")
os.makedirs(OUTPUT, exist_ok=True)

# 분할 기준 경계
TRAIN_END = "2025-08"
TEST_START, TEST_END = "2025-09", "2026-05"
FUT_START, FUT_END = "2026-06", "2026-12"


# ----------------------------------------------------------------------
# 1. 데이터 로드 & 월 키('YYYY-MM') 통일
# ----------------------------------------------------------------------
def to_month_str(s):
    s = pd.to_datetime(s.astype(str), errors="coerce")
    return s.dt.strftime("%Y-%m")


def load_data():
    f_act = f"{RAWS}/customer_actuals_10yr.xlsx"
    f_scfi = f"{RAWS}/scfi_composite.xlsx"
    f_scfi_fc = f"{RAWS}/scfi_forecast_raw.xlsx"

    cost = pd.read_excel(f_act, sheet_name="월별 물류비").rename(columns={"value": "cost"})
    vol = pd.read_excel(f_act, sheet_name="월별 물동량").rename(columns={"value": "volume"})
    vol_fc = pd.read_excel(f_act, sheet_name="월별 물동량 전망").rename(columns={"value": "volume"})

    scfi = pd.read_excel(f_scfi, sheet_name="월별 SCFI")
    scfi = scfi[scfi["route"] == "SCFI Composite"][["month", "scfi_value"]].rename(
        columns={"scfi_value": "scfi"})
    scfi_fc = pd.read_excel(f_scfi_fc, sheet_name="월별 SCFI 전망").rename(
        columns={"Forecast_SCFi_Approx": "scfi"})

    for df in (cost, vol, vol_fc, scfi, scfi_fc):
        df["month"] = to_month_str(df["month"])

    volume = pd.concat([vol[["month", "volume"]], vol_fc[["month", "volume"]]], ignore_index=True)
    scfi_all = pd.concat([scfi[["month", "scfi"]], scfi_fc[["month", "scfi"]]], ignore_index=True)
    return cost[["month", "cost"]], volume, scfi_all


# ----------------------------------------------------------------------
# 2. 통합 테이블 구성 (병합 → SCFI 시차 → 원핫 → split 라벨)
#    ※ 물류비 lag(lag_cost)는 사용하지 않으므로 생성하지 않는다.
# ----------------------------------------------------------------------
def build_table(cost, volume, scfi_all):
    months = pd.period_range("2016-01", "2026-12", freq="M").strftime("%Y-%m")
    df = pd.DataFrame({"month": months})

    df = (df.merge(cost, on="month", how="left")
            .merge(scfi_all, on="month", how="left")
            .merge(volume, on="month", how="left"))
    df = df.sort_values("month").reset_index(drop=True)

    # SCFI 시차: df 시작(2016-01) 이전 SCFI 실측까지 활용하기 위해
    # df 내부 shift가 아니라 전체 SCFI 계열에서 월 오프셋으로 직접 매핑한다.
    s = scfi_all.drop_duplicates("month").set_index("month")["scfi"]
    for k in (1, 2, 3):
        df[f"lag_scfi_{k}"] = df["month"].map(
            lambda mn, k=k: s.get((pd.Period(mn, "M") - k).strftime("%Y-%m"), np.nan))

    m = pd.to_datetime(df["month"]).dt.month
    for i in range(1, 13):
        df[f"month_{i}"] = (m == i).astype(int)

    def label(mn):
        if mn <= TRAIN_END:
            return "train"
        if TEST_START <= mn <= TEST_END:
            return "test"
        if FUT_START <= mn <= FUT_END:
            return "future"
        return "drop"
    df["split"] = df["month"].map(label)
    return df


FEATURES = (["lag_scfi_1", "lag_scfi_2", "lag_scfi_3", "volume"]
            + [f"month_{i}" for i in range(1, 13)])
# 선형/라쏘용: 더미 함정 방지를 위해 month_1 제외
FEATURES_LINEAR = [c for c in FEATURES if c != "month_1"]


# ----------------------------------------------------------------------
# 3. 모형 구성/학습
# ----------------------------------------------------------------------
def build_models():
    return {
        "다중회귀": (LinearRegression(), FEATURES_LINEAR),
        "라쏘": (make_pipeline(StandardScaler(),
                              LassoCV(cv=5, max_iter=100000, random_state=0)), FEATURES_LINEAR),
        "의사결정나무": (DecisionTreeRegressor(max_depth=4, min_samples_leaf=5, random_state=0),
                     FEATURES),
    }


def fit_models(data):
    models = {}
    for name, (est, feats) in build_models().items():
        models[name] = (est.fit(data[feats].values, data["cost"].values), feats)
    return models


def predict(model_feat, row_df):
    model, feats = model_feat
    return model.predict(row_df[feats].values)


def rmse(y, yh):
    return float(np.sqrt(mean_squared_error(y, yh)))


# ----------------------------------------------------------------------
# 메인
# ----------------------------------------------------------------------
def main():
    cost, volume, scfi_all = load_data()
    df = build_table(cost, volume, scfi_all)

    feat_cols = ["lag_scfi_1", "lag_scfi_2", "lag_scfi_3", "volume"]
    feat_ok = df[feat_cols].notna().all(axis=1)

    train = df[(df["split"] == "train") & feat_ok & df["cost"].notna()].copy()
    test = df[(df["split"] == "test") & feat_ok & df["cost"].notna()].copy()
    future = df[(df["split"] == "future") & feat_ok].copy()

    print(f"[INFO] 물류비 lag 제거: 독립변수 = 1/2/3개월전 SCFI, 물동량, 월(원핫)")
    print(f"[INFO] 훈련 시작 자동 조정: 지정 2015-01 → 실제 {train['month'].min()} "
          f"(물류비 실적이 2016-01부터 존재)")
    print(f"[INFO] 훈련 {train['month'].min()}~{train['month'].max()} ({len(train)}개월) / "
          f"테스트 {test['month'].min()}~{test['month'].max()} ({len(test)}개월) / "
          f"미래 {future['month'].min()}~{future['month'].max()} ({len(future)}개월)")

    # (A) 평가용 모형: 훈련데이터로만 적합 → 테스트로 일반화 성능 평가
    eval_models = fit_models(train)
    pred_train = {n: predict(mf, train) for n, mf in eval_models.items()}
    pred_test = {n: predict(mf, test) for n, mf in eval_models.items()}

    rows = []
    for name in eval_models:
        rows.append({
            "모형": name,
            "훈련 RMSE": rmse(train["cost"], pred_train[name]),
            "훈련 R²": r2_score(train["cost"], pred_train[name]),
            "테스트 RMSE": rmse(test["cost"], pred_test[name]),
            "테스트 R²": r2_score(test["cost"], pred_test[name]),
        })
    metrics = pd.DataFrame(rows)
    best = metrics.loc[metrics["테스트 RMSE"].idxmin(), "모형"]

    print("\n===== 모형별 성능 (훈련데이터 적합, RMSE 단위: 원) =====")
    show = metrics.copy()
    for c in ["훈련 RMSE", "테스트 RMSE"]:
        show[c] = show[c].map(lambda v: f"{v:,.0f}")
    for c in ["훈련 R²", "테스트 R²"]:
        show[c] = show[c].map(lambda v: f"{v:.4f}")
    print(show.to_string(index=False))
    print(f"[INFO] 테스트 RMSE 최저(추천 최종모델): {best}")

    # (B) 최종 모형: 훈련+테스트 전체로 재적합 → 미래 예측
    full = pd.concat([train, test], ignore_index=True)
    final_models = fit_models(full)
    pred_future = {n: predict(mf, future) for n, mf in final_models.items()}

    fut_tbl = pd.DataFrame({"month": future["month"].values})
    for name in final_models:
        fut_tbl[name] = pred_future[name]
    fut_tbl["추천모델_예측"] = pred_future[best]   # 테스트 RMSE 최저 모형 기준

    print(f"\n===== 최종모델(훈련+테스트 적합) 미래 예측 2026-06~12, 단위: 원 =====")
    print(fut_tbl.assign(**{c: fut_tbl[c].map(lambda v: f"{v:,.0f}")
                            for c in fut_tbl.columns if c != "month"}).to_string(index=False))

    # ------------------------------------------------------------------
    # 통합 입력 테이블 엑셀 (물류비 lag 제외)
    # ------------------------------------------------------------------
    out_cols = (["month", "cost", "scfi", "lag_scfi_1", "lag_scfi_2", "lag_scfi_3", "volume"]
                + [f"month_{i}" for i in range(1, 13)] + ["split"])
    table = df[df["split"] != "drop"][out_cols].copy()
    xlsx_path = f"{OUTPUT}/model_input_table.xlsx"
    table.to_excel(xlsx_path, index=False, sheet_name="model_input")
    _style_table(xlsx_path, "model_input")
    print(f"\n[저장] 통합 입력 테이블 → {xlsx_path}  (행 {len(table)}, 열 {len(out_cols)})")

    # 성능 테이블
    res_path = f"{OUTPUT}/model_results.xlsx"
    metrics.to_excel(res_path, index=False, sheet_name="성능")
    print(f"[저장] 성능 테이블 → {res_path}")

    # 최종모델 미래 예측 결과
    final_path = f"{OUTPUT}/final_model_result.xlsx"
    with pd.ExcelWriter(final_path, engine="openpyxl") as w:
        fut_tbl.to_excel(w, index=False, sheet_name="최종예측")
        pd.DataFrame({"항목": ["추천 최종모델(테스트 RMSE 최저)", "적합 데이터"],
                      "값": [best, f"훈련+테스트 {full['month'].min()}~{full['month'].max()}"]}
                     ).to_excel(w, index=False, sheet_name="요약")
    print(f"[저장] 최종모델 미래예측 → {final_path}")

    # ------------------------------------------------------------------
    # 시각화: 실적=검정, 훈련예측=파랑, 테스트예측=빨강, 최종모델 미래예측=초록 점선
    # ------------------------------------------------------------------
    x_actual = pd.to_datetime(df.loc[df["cost"].notna(), "month"])
    y_actual = df.loc[df["cost"].notna(), "cost"]
    x_train = pd.to_datetime(train["month"]); x_test = pd.to_datetime(test["month"])
    x_fut = pd.to_datetime(future["month"])
    boundary = pd.to_datetime(TEST_START); fut_boundary = pd.to_datetime(FUT_START)

    fig, axes = plt.subplots(3, 1, figsize=(13, 12), sharex=True)
    for ax, name in zip(axes, eval_models):
        ax.plot(x_actual, y_actual / 1e8, color="black", lw=1.6, label="실적")
        ax.plot(x_train, pred_train[name] / 1e8, color="blue", lw=1.4, label="훈련 예측")
        ax.plot(x_test, pred_test[name] / 1e8, color="red", lw=1.8, marker="o", ms=3, label="테스트 예측")
        ax.plot(x_fut, pred_future[name] / 1e8, color="green", lw=1.8, ls="--",
                marker="s", ms=3, label="최종모델 미래예측")
        ax.axvline(boundary, color="gray", ls=":", lw=1)
        ax.axvline(fut_boundary, color="gray", ls=":", lw=1)
        r = metrics.loc[metrics["모형"] == name].iloc[0]
        tag = " ★추천" if name == best else ""
        ax.set_title(f"{name}{tag}  (테스트 RMSE={r['테스트 RMSE']/1e8:.3f}억, R²={r['테스트 R²']:.3f})")
        ax.set_ylabel("물류비 (억원)")
        ax.legend(loc="upper left", fontsize=9, ncol=4)
        ax.grid(alpha=0.3)
    axes[-1].set_xlabel("월")
    fig.suptitle("월별 물류비 실적 vs 예측 (물류비 lag 제외 / 미래=훈련+테스트 최종모델)", fontsize=14, y=0.995)
    fig.tight_layout()
    png_path = f"{OUTPUT}/forecast_plot.png"
    fig.savefig(png_path, dpi=130, bbox_inches="tight")
    print(f"[저장] 그래프 → {png_path}")


def _style_table(path, sheet):
    from openpyxl import load_workbook
    from openpyxl.styles import Font, Alignment, PatternFill
    wb = load_workbook(path)
    ws = wb[sheet]
    head_fill = PatternFill("solid", fgColor="DDE7F0")
    for cell in ws[1]:
        cell.font = Font(name="Arial", bold=True)
        cell.fill = head_fill
        cell.alignment = Alignment(horizontal="center")
    for col in ws.iter_cols(min_row=2):
        for cell in col:
            cell.font = Font(name="Arial")
    ws.freeze_panes = "B2"
    for c, w in {"A": 9, "B": 15, "C": 9, "D": 12, "E": 12, "F": 12, "G": 9}.items():
        ws.column_dimensions[c].width = w
    wb.save(path)


if __name__ == "__main__":
    main()
