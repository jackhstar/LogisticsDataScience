# -*- coding: utf-8 -*-
"""
make_diagnostics.py  —  진단 계산기 (계산 코드, 고정)
------------------------------------------------------------------------
물류비 변동 원인을 통계로 분해해, 대시보드가 "읽기만" 하면 되도록
outputs/analysis/diagnostics.xlsx (정확히 5시트)로 미리 저장한다.

핵심 재현성 원리
  - LMG(그룹 단위 Shapley R² 분해)용 R² 는 "표준화 + 미세 ridge(λ=1e-8, 절편
    제외) 정규방정식의 닫힌 해"로 유일하게 고정한다(어떤 PC에서도 동일 숫자).
  - %는 정수 반올림 후 최대잔차법(largest-remainder)으로 합 100 보장.
  - 계절·민감도는 자기상관을 뺀 외생회귀(운임·유가·물동·환율·계절)로 산출한다.

실행:  python make_diagnostics.py
"""
import os
import sys
import shutil
import datetime
import itertools
from math import factorial

import numpy as np
import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

# --------------------------------------------------------------------------
# 경로 (어디서 실행해도 동작: __file__ 기준 절대경로)
# --------------------------------------------------------------------------
ROOT = os.path.dirname(os.path.abspath(__file__))
RAWS = os.path.join(ROOT, "raws")
ANALYSIS = os.path.join(ROOT, "outputs", "analysis")
DIAG_XLSX = os.path.join(ANALYSIS, "diagnostics.xlsx")

MONTH_DUMMIES = [f"month_{i}" for i in range(2, 13)]           # 1월 기준
GROUPS = {
    "자기상관": ["lag_cost_1", "lag_cost_2", "lag_cost_3"],
    "운임":     ["scfi", "lag_scfi_1", "lag_scfi_2", "lag_scfi_3"],
    "유가":     ["wti"],
    "물동":     ["volume"],
    "환율":     ["fx"],
    "계절":     MONTH_DUMMIES,
}
EXOG = ["scfi", "lag_scfi_1", "lag_scfi_2", "lag_scfi_3",
        "wti", "volume", "fx"] + MONTH_DUMMIES                 # 자기상관 제외
RIDGE_LAMBDA = 1e-8


# --------------------------------------------------------------------------
# 데이터 로딩 / 표본 구성
# --------------------------------------------------------------------------
def _norm_month(series):
    return series.astype(str).str.slice(0, 7)


def load_sample():
    mi_path = os.path.join(ANALYSIS, "model_input_table.xlsx")
    fx_path = os.path.join(RAWS, "ecos_fx_wti.xlsx")
    if not os.path.exists(mi_path):
        sys.exit(f"[중단] 입력이 없다: {mi_path}\n  → 먼저 모델 재학습(②)을 실행하라.")

    mi = pd.read_excel(mi_path, sheet_name="model_input")
    fx = pd.read_excel(fx_path, sheet_name="월별 환율")[["month", "value"]].rename(columns={"value": "fx"})
    wti = pd.read_excel(fx_path, sheet_name="월별 WTI")[["month", "value"]].rename(columns={"value": "wti"})
    for df in (mi, fx, wti):
        df["month"] = _norm_month(df["month"])

    d = mi.merge(fx, on="month", how="left").merge(wti, on="month", how="left")

    all_cols = sum(GROUPS.values(), [])
    samp = d[d["split"].isin(["train", "test"])].copy()
    samp = samp.dropna(subset=["cost"] + all_cols).reset_index(drop=True)
    return samp


# --------------------------------------------------------------------------
# 결정론적 R² (표준화 + 미세 ridge 정규방정식 닫힌 해)
# --------------------------------------------------------------------------
def make_r2(samp):
    y = samp["cost"].values.astype(float)
    yc = y - y.mean()
    sst = float((yc ** 2).sum())

    def r2(cols):
        if not cols:
            return 0.0
        X = samp[cols].values.astype(float)
        mu = X.mean(axis=0)
        sd = X.std(axis=0)
        sd[sd == 0] = 1.0
        Z = (X - mu) / sd
        A = Z.T @ Z + RIDGE_LAMBDA * np.eye(Z.shape[1])
        beta = np.linalg.solve(A, Z.T @ yc)
        pred = Z @ beta
        return 1.0 - float(((yc - pred) ** 2).sum()) / sst

    return r2, sst


def lmg(group_dict, r2):
    """그룹 단위 Shapley R² 분해 (모든 투입 순서의 한계 기여 평균)."""
    keys = list(group_dict)
    k = len(keys)
    contrib = {g: 0.0 for g in keys}
    cache = {}

    def R(frozen):
        key = frozenset(frozen)
        if key not in cache:
            cache[key] = r2(sum((group_dict[g] for g in frozen), []))
        return cache[key]

    for g in keys:
        others = [x for x in keys if x != g]
        for r in range(len(others) + 1):
            w = factorial(r) * factorial(k - r - 1) / factorial(k)
            for S in itertools.combinations(others, r):
                contrib[g] += w * (R(list(S) + [g]) - R(list(S)))
    return contrib


def to_pct_int(contrib, order):
    """기여도를 총합 대비 %로 → 정수 반올림 후 최대잔차법으로 합 100 보장."""
    total = sum(contrib.values())
    raw = {g: contrib[g] / total * 100.0 for g in contrib}
    floor = {g: int(np.floor(raw[g])) for g in raw}
    rem = 100 - sum(floor.values())
    rank = sorted(raw, key=lambda g: (raw[g] - floor[g]), reverse=True)
    for i in range(rem):
        floor[rank[i]] += 1
    return [(g, floor[g]) for g in order]


# --------------------------------------------------------------------------
# 외생 OLS (자기상관 제외, 조건수 안정) — 계절 C / 민감도용
# --------------------------------------------------------------------------
def ols_with_intercept(samp, cols):
    X = samp[cols].values.astype(float)
    y = samp["cost"].values.astype(float)
    Xd = np.column_stack([np.ones(len(X)), X])
    beta, *_ = np.linalg.lstsq(Xd, y, rcond=None)
    intercept = beta[0]
    coef = dict(zip(cols, beta[1:]))
    return intercept, coef


# --------------------------------------------------------------------------
# 계절효과 A — 12개월 중심이동평균으로 추세 제거한 순수 계절성(원)
# --------------------------------------------------------------------------
def seasonal_index_A():
    path = os.path.join(RAWS, "customer_actuals_10yr.xlsx")
    cost = pd.read_excel(path, sheet_name="월별 물류비")
    cost["month"] = _norm_month(cost["month"])
    cost = cost.dropna(subset=["value"]).sort_values("month").reset_index(drop=True)
    s = cost["value"].astype(float)
    mons = cost["month"].str.slice(5, 7).astype(int).values

    trend = s.rolling(12, center=True).mean().values      # 12개월 중심이동평균
    detr = s.values - trend
    seas = {}
    for m in range(1, 13):
        vals = detr[(mons == m) & ~np.isnan(detr)]
        seas[m] = float(np.mean(vals))
    overall = float(np.mean([seas[m] for m in range(1, 13)]))  # 연평균 기준(합≈0)
    return {m: seas[m] - overall for m in range(1, 13)}, cost


# --------------------------------------------------------------------------
# 엑셀 저장 + 서식
# --------------------------------------------------------------------------
def style_sheet(ws):
    hdr_font = Font(bold=True, color="FFFFFF")
    hdr_fill = PatternFill("solid", fgColor="305496")
    center = Alignment(horizontal="center", vertical="center")
    for c in ws[1]:
        c.font = hdr_font
        c.fill = hdr_fill
        c.alignment = center
    for col in ws.columns:
        width = max((len(str(c.value)) for c in col if c.value is not None), default=8)
        ws.column_dimensions[get_column_letter(col[0].column)].width = max(12, width + 4)
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.alignment = center
    ws.freeze_panes = "A2"


def save_diagnostics(sheets):
    os.makedirs(ANALYSIS, exist_ok=True)
    with pd.ExcelWriter(DIAG_XLSX, engine="openpyxl") as xw:
        for name, df in sheets.items():
            df.to_excel(xw, sheet_name=name, index=False)
    wb = openpyxl.load_workbook(DIAG_XLSX)
    for name in sheets:
        style_sheet(wb[name])
    wb.save(DIAG_XLSX)


def snapshot():
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    dst = os.path.join(ANALYSIS, "log", stamp)
    os.makedirs(dst, exist_ok=True)
    for f in os.listdir(ANALYSIS):
        src = os.path.join(ANALYSIS, f)
        if os.path.isfile(src):
            shutil.copy2(src, os.path.join(dst, f))
    return dst


# --------------------------------------------------------------------------
# 메인
# --------------------------------------------------------------------------
def main():
    samp = load_sample()
    r2, _ = make_r2(samp)
    n = len(samp)
    period = f"{samp['month'].min()}~{samp['month'].max()}"

    # (1) LMG_포함 — 6개 그룹
    c_inc = lmg(GROUPS, r2)
    r2_inc = sum(c_inc.values())
    inc_rows = to_pct_int(c_inc, order=["자기상관", "운임", "유가", "물동", "환율", "계절"])
    df_inc = pd.DataFrame(inc_rows, columns=["동인", "기여도(%)"])

    # (2) LMG_제외 — 자기상관 제외 5개 그룹
    g_exc = {k: v for k, v in GROUPS.items() if k != "자기상관"}
    c_exc = lmg(g_exc, r2)
    r2_exc = sum(c_exc.values())
    exc_rows = to_pct_int(c_exc, order=["운임", "유가", "물동", "환율", "계절"])
    df_exc = pd.DataFrame(exc_rows, columns=["동인", "기여도(%)"])

    # (3) 운임시차 — 운임 4개 시차를 개별 그룹으로 두고 LMG 분해 후 운임 4항 재정규화
    lag_groups = {
        "당월": ["scfi"], "1개월전": ["lag_scfi_1"],
        "2개월전": ["lag_scfi_2"], "3개월전": ["lag_scfi_3"],
        "자기상관": ["lag_cost_1", "lag_cost_2", "lag_cost_3"],
        "유가": ["wti"], "물동": ["volume"], "환율": ["fx"], "계절": MONTH_DUMMIES,
    }
    c_lag = lmg(lag_groups, r2)
    lag_keys = ["당월", "1개월전", "2개월전", "3개월전"]
    lag_tot = sum(c_lag[k] for k in lag_keys)
    df_lag = pd.DataFrame(
        [(k, round(c_lag[k] / lag_tot * 100.0, 1)) for k in lag_keys],
        columns=["운임 시차", "상대 기여(%)"],
    )

    # (4) 계절효과 — A 원계절지수 / B 조건부월효과 / C 관성미포함
    seasA, _cost = seasonal_index_A()
    _, coef_full = ols_with_intercept(samp, sum(GROUPS.values(), []))   # B (lag_cost 포함)
    _, coef_exog = ols_with_intercept(samp, EXOG)                        # C (외생)

    def month_eff(coef):
        out = {1: 0.0}
        for i in range(2, 13):
            out[i] = float(coef.get(f"month_{i}", 0.0))
        return out

    b_eff = month_eff(coef_full)
    c_eff = month_eff(coef_exog)
    df_season = pd.DataFrame(
        [(m, round(seasA[m]), round(b_eff[m]), round(c_eff[m])) for m in range(1, 13)],
        columns=["월", "원계절지수(A, 원)", "조건부월효과(B, 원)", "관성미포함(C, 참고, 원)"],
    )

    # (5) 민감도 — 자기상관 제외 외생회귀 계수 기준
    s1 = coef_exog["lag_scfi_1"] * 100.0
    s2 = coef_exog["lag_scfi_2"] * 100.0
    s3 = coef_exog["lag_scfi_3"] * 100.0
    headline = (coef_exog["lag_scfi_1"] + coef_exog["lag_scfi_2"] + coef_exog["lag_scfi_3"]) / 3.0 * 100.0
    df_sens = pd.DataFrame(
        [
            ("SCFI 1개월전 100p (참고)", round(s1)),
            ("SCFI 2개월전 100p (참고)", round(s2)),
            ("SCFI 3개월전 100p (참고)", round(s3)),
            ("운임 100p당 한 달치 효과(1·2·3개월전 평균)", round(headline)),
        ],
        columns=["항목", "물류비 민감도(원)"],
    )

    sheets = {
        "LMG_포함": df_inc,
        "LMG_제외": df_exc,
        "운임시차": df_lag,
        "계절효과": df_season,
        "민감도": df_sens,
    }
    save_diagnostics(sheets)
    snap = snapshot()

    # 콘솔 요약
    print("=" * 64)
    print("make_diagnostics.py  진단 계산 완료")
    print("=" * 64)
    print(f" 표본 n={n}  구간 {period}")
    print(f" 전체 R²  LMG_포함={r2_inc:.4f}   LMG_제외={r2_exc:.4f}")
    print("-" * 64)
    print(" [LMG_포함]  " + "  ".join(f"{g}:{p}%" for g, p in inc_rows))
    print(" [LMG_제외]  " + "  ".join(f"{g}:{p}%" for g, p in exc_rows) +
          "   → 최대동인=" + max(exc_rows, key=lambda t: t[1])[0])
    print(" [운임시차]  " + "  ".join(f"{k}:{v}%" for k, v in df_lag.values))
    print(f" [민감도]   운임 100p당 한 달치 효과 = {round(headline):,}원")
    print("-" * 64)
    print(f" 저장: {DIAG_XLSX}")
    print(f" 스냅샷: {snap}")


if __name__ == "__main__":
    main()
