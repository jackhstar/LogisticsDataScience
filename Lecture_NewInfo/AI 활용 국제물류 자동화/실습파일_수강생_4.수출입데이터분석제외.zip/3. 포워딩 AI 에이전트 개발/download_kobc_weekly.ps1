﻿# ============================================================
# KOBC 주간통합 시황 리포트 최신본 자동 다운로드
#   - 브라우저/대화상자 없이 PowerShell만으로 동작
#   - 목록 최상단(가장 최근) 글의 PDF를 kobc 폴더에 자동 저장
# 사용법:  powershell -ExecutionPolicy Bypass -File download_kobc_weekly.ps1
# ============================================================
param(
    [string]$OutDir = (Join-Path $PSScriptRoot 'kobc')
)

$ProgressPreference = 'SilentlyContinue'
$ErrorActionPreference = 'Stop'

$ua      = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36'
$listUrl = 'https://www.kobc.or.kr/ebz/shippinginfo/reportWeekly/list.do?mId=0202000000'
$host0   = 'https://www.kobc.or.kr'

Write-Host '목록 페이지를 읽는 중...'
$list = Invoke-WebRequest -Uri $listUrl -SessionVariable sess -UserAgent $ua -UseBasicParsing

# 최상단(가장 최근) 글의 다운로드 인자 파싱: fn_egov_downFile('atchFileId','fileSn')
$m = [regex]::Match($list.Content, "fn_egov_downFile\('([0-9a-f]+)'\s*,\s*'([0-9a-f]+)'\)")
if (-not $m.Success) { throw '다운로드 링크(fn_egov_downFile)를 찾지 못했습니다. 사이트 구조가 바뀌었을 수 있습니다.' }
$atchFileId = $m.Groups[1].Value
$fileSn     = $m.Groups[2].Value

# 실제 파일 다운로드 (GET)
$dlUrl = "$host0/ebz/cmm/fms/FileDown.do?atchFileId=$atchFileId&fileSn=$fileSn"
Write-Host '파일 다운로드 중...'
$resp = Invoke-WebRequest -Uri $dlUrl -WebSession $sess -UserAgent $ua -Headers @{ Referer = $listUrl } -UseBasicParsing

if ($resp.RawContentLength -lt 1000) { throw "다운로드 응답이 비정상입니다(bytes=$($resp.RawContentLength))." }

# Content-Disposition 파일명에서 보고서 날짜 추출 → 깔끔한 파일명 생성
$cd  = [string]$resp.Headers['Content-Disposition']
$rawName = ([regex]::Match($cd, 'filename="?([^"]+)"?')).Groups[1].Value
$decoded = [uri]::UnescapeDataString($rawName).Replace('+', ' ')

$d = [regex]::Match($decoded, "(\d{2})\.\s*(\d{1,2})\.\s*(\d{1,2})\.")
if ($d.Success) {
    $yyyy = '20' + $d.Groups[1].Value
    $mm   = $d.Groups[2].Value.PadLeft(2, '0')
    $dd   = $d.Groups[3].Value.PadLeft(2, '0')
    $fileName = "KOBC_주간통합_시황리포트_$yyyy$mm$dd.pdf"
} else {
    $fileName = if ($decoded) { $decoded } else { 'KOBC_주간통합_시황리포트.pdf' }
}

if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory -Path $OutDir | Out-Null }
$outPath = Join-Path $OutDir $fileName

if (Test-Path $outPath) {
    Write-Host "이미 최신본이 존재합니다: $outPath" -ForegroundColor Yellow
} else {
    [System.IO.File]::WriteAllBytes($outPath, $resp.Content)
    Write-Host "저장 완료: $outPath ($($resp.Content.Length) bytes)" -ForegroundColor Green
}
