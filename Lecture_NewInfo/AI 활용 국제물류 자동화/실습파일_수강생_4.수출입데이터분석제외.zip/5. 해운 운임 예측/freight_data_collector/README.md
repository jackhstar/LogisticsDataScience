# Freight Data Collector & Market Workflow

공개된 해운·물류 시장자료(SCFI·KCCI·WTI·KOBC)를 자동으로 **수집 → 병합 →
분석계산 → 시황 서술 → HTML 리포트**까지 처리하는 프로젝트다. 단순 수집기에서
출발해, 현재는 두 가지 시황 리포트 워크플로우(LLM 서술 / 규칙 기반)를 포함한다.

최종 업데이트: 2026-06-17

## 1. 전체 파이프라인

```
[수집] collect_*.py ──► [병합] merge_freight_data.py ──► output/freight_market_dataset.csv
                                                              │
                                          ┌───────────────────┴───────────────────┐
                                          ▼                                         ▼
                            [규칙 기반] run_market_workflowbypython.py     [LLM] build_context.py
                              rules.py 가 변화율→문장 생성                  → output/context.json (숫자만)
                                          │                                  → LLM 이 시황 서술 작성
                                          ▼                                  → output/narrative.json
                            analysis/market_analysis_bypython_*.html          → build_report.py
                                                                              → analysis/market_analysis_*.html
```

## 2. 두 워크플로우(스킬) 비교

| 구분 | freight-market-workflow (LLM 서술) | freight-market-workflowbypython (규칙 기반) |
|------|------|------|
| 분석 문장 작성 | LLM 이 context.json 숫자를 읽고 직접 서술 | `rules.py` 가 변화율을 임계표에 대입해 결정론적으로 생성 |
| 산출 단계 | build_context.py → (LLM)narrative.json → build_report.py | run_market_workflowbypython.py 한 번에 수집~리포트 |
| 재현성 | 낮음(실행마다 서술 변동) | 완벽(같은 입력 → 같은 문장) |
| 정성 변수 반영 | 가능 | 불가(수치 모멘텀만) |
| 적합 용도 | 의사결정용 심층 브리핑 | 정기·반복 모니터링, 비교 추세 |

## 3. 구성 파일

| 파일 | 역할 |
|------|------|
| `collect_eia_wti.py` | EIA(미국 에너지정보청) WTI 원유 현물가격 수집 (API) |
| `collect_scfi_composite.py` | 상하이 항운교역소 SCFI 종합지수 수집 |
| `collect_kcci_composite.py` | KOBC KCCI 종합지수 수집 |
| `collect_kobc_focus.py` | KOBC 주간 통합 시황 리포트 메타·PDF 수집 |
| `merge_freight_data.py` | `output/` 수집 CSV 병합 → `freight_market_dataset.csv` |
| `rules.py` | 변화율 → 한국어 분석 문장 규칙 엔진(규칙 기반 워크플로우용) |
| `run_market_workflowbypython.py` | 규칙 기반 워크플로우 오케스트레이터(수집→병합→리포트) |
| `skills/freight-market-workflow/scripts/build_context.py` | 수집→병합→분석계산 → `context.json`(LLM 미사용) |
| `skills/freight-market-workflow/scripts/build_report.py` | `context.json`+`narrative.json` → HTML 리포트 |
| `run_freight_bypython.bat` | PC 작업 스케줄러용 실행 배치(규칙 기반) |
| `register_schedule_bypython.bat` | 위 배치를 매일 자동 실행 등록하는 헬퍼 |

## 4. 설치

```bash
pip install -r requirements.txt
```

필요 패키지: `requests`, `pandas`, `python-dotenv`, `lxml`(pandas `read_html` 의존).

여러 Python 이 설치된 경우 실행에 쓰는 그 Python 에 패키지가 설치돼 있어야 한다.
확인: `python -c "import requests, pandas, lxml, dotenv; print('OK')"`

## 5. 환경변수 (.env)

EIA API 는 무료 키가 필요하다 (https://www.eia.gov/opendata/register.php).

```
EIA_API_KEY=your_api_key_here
```

키가 없으면 `collect_eia_wti.py` 는 명확한 오류 메시지를 출력하고 로그에 기록한다.

## 6. 실행

```bash
# (A) 규칙 기반 워크플로우 — 한 번에 수집→병합→리포트
python run_market_workflowbypython.py --project "C:\logistics\claude\freight_data_collector"

# (B) LLM 워크플로우 1단계 — context.json 생성
python skills/freight-market-workflow/scripts/build_context.py --project "<프로젝트 폴더>"
#     2단계 — LLM 이 context.json 을 읽고 output/narrative.json 작성
#     3단계 — 리포트 생성
python skills/freight-market-workflow/scripts/build_report.py --project "<프로젝트 폴더>"

# 공통 옵션
#   --project   : 수집기·output/ 가 있는 작업 폴더 지정(미지정 시 자동 탐지 실패 가능)
#   --no-collect: 수집을 건너뛰고 기존 output/ CSV 로 병합·계산만 수행
```

개별 수집기만 따로 돌릴 수도 있다: `python collect_eia_wti.py` 등.

## 7. 출력 구조 (`output/`)

```
output/
├── collection_log.csv          # 실행/오류 로그
├── data_quality_report.csv     # 자료원별 수집 상태·결측 리포트
├── eia_wti.csv                 # WTI 현물 시계열
├── scfi_composite.csv          # SCFI 종합지수 시계열
├── kcci_composite.csv          # KCCI 종합지수(최신 1행, 발행일 포함)
├── kcci_history.csv            # KCCI (발행일, 종합지수) 누적 이력 — 주간 변화 계산용
├── kobc_focus_meta.csv         # KOBC 주간 리포트 제목·발행일·PDF URL
├── kobc_focus_latest.pdf       # KOBC 주간 리포트 PDF
├── freight_market_dataset.csv  # 병합 시계열(merge 결과)
├── context.json                # 분석계산 결과(숫자) — LLM 워크플로우 중간물
├── narrative.json              # LLM 시황 서술 — LLM 워크플로우 중간물
└── scheduler_log/              # 배치 스케줄 실행 로그
```

리포트 산출물은 `analysis/market_analysis_*.html`(LLM) /
`analysis/market_analysis_bypython_*.html`(규칙 기반)로 저장된다. 타임스탬프는
KST(Asia/Seoul) 기준이다.

## 8. KCCI·KOBC 데이터 처리 규약 (중요)

리포트의 KCCI·KOBC 값/발행일은 **수집본을 우선**한다. 과거에는 권위파일
`ctx_out.json` 을 우선해 수집 날짜가 반영되지 않는 문제가 있었고, 다음과 같이
바로잡았다.

- KCCI 종합지수·발행일은 `output/kcci_composite.csv`, KOBC 제목·발행일은
  `output/kobc_focus_meta.csv` 에서 우선 읽어 **수집 날짜가 자동 반영**된다.
  `ctx_out.json` 은 없으면 그만이며, 사용 시에도 폴백 용도다.
- KCCI 수집 표의 셀 순서가 바뀌어도(라벨 역전) 견고하도록, 종합지수는 행 내
  숫자 중 **지수 범위(≥500)의 최댓값**으로 판정한다.
- KCCI 주간 변화율은 `kcci_history.csv` 의 직전 발행일 종합지수와 비교해
  계산한다. 이력에 직전 값이 없으면 주간 변화는 생략된다.
- `build_context.py` 말미에는 스킬 등록(캐시) 시 파일 끝이 잘리는 현상에 대한
  **절단 방어 패딩** 주석이 있다. 삭제하지 않는다.

## 9. 네트워크 제약 (반드시 확인)

수집 단계는 외부 서버(EIA·KOBC·상하이 항운교역소) 접속이 필요하다. **Cowork 코드
실행 샌드박스나 Cowork 내장 스케줄은 망 분리되어 외부 인터넷이 차단**되므로, 그
환경에서 수집을 돌리면 `ConnectionError` 로 실패하고 폴더의 마지막 수집분으로만
처리된다.

따라서 **최신 데이터 수집은 인터넷이 되는 사용자 PC 에서 실행**해야 한다. 수집까지
끝낸 뒤의 병합·분석·서술·리포트 단계는 Cowork 에서도 처리할 수 있다.

## 10. 자동화(스케줄)

PC 에서 정기 자동 실행은 **Windows 작업 스케줄러**를 쓴다(Cowork 스케줄은 9번
제약으로 수집 불가).

```bat
:: 1) 한 번 직접 실행해 정상 동작 확인
run_freight_bypython.bat

:: 2) 매일 자동 실행 등록(관리자 권한 cmd) — 시간은 /ST 로 지정
schtasks /Create /TN "FreightMarketBypython" ^
  /TR "\"C:\logistics\claude\freight_data_collector\run_freight_bypython.bat\"" ^
  /SC DAILY /ST 16:40 /F

:: 확인 / 시간변경 / 해제
schtasks /Query  /TN "FreightMarketBypython"
schtasks /Change /TN "FreightMarketBypython" /ST 16:40
schtasks /Delete /TN "FreightMarketBypython" /F
```

작업을 "사용자가 로그온할 때만 실행"으로 두면 계정 암호 저장이 필요 없다. 자세한
안내는 `배치파일_사용안내.html` 참조.

## 11. 규약

- 모든 날짜는 `YYYY-MM-DD` 로 표기한다.
- 수집 단계는 개별 실패를 건너뛰고 상태만 기록하므로, 일부 자료원이 막혀도
  전체 파이프라인은 멈추지 않는다.
- 각 수집 스크립트 상단 상수(`*_URL` 등)만 수정하면 자료원 변경에 대응할 수 있다.
- 웹 표가 JavaScript 로 렌더링되거나 구조가 바뀌면 `requests`+`pandas.read_html`
  방식이 실패할 수 있으며, 추후 Playwright/Selenium 모듈로 교체할 수 있도록
  설계되어 있다.
