"""EIA WTI 원유 현물가격(RWTC, Cushing WTI Spot, USD/배럴) 수집 스크립트.

자료원: 미국 에너지정보청(EIA) Open Data API v2
필요 환경변수: EIA_API_KEY (.env 에 설정, 무료 발급)
수집 범위: 오늘 기준 최근 365일 일간(daily) 데이터
출력: output/eia_wti.csv
로그: output/collection_log.csv
"""

import csv
import os
from datetime import datetime, timedelta

import requests
from dotenv import load_dotenv

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
LOG_FILE = os.path.join(OUTPUT_DIR, "collection_log.csv")
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "eia_wti.csv")
SOURCE_NAME = "eia_wti"
SOURCE_LABEL = "EIA WTI Crude Oil Spot Price"
API_URL = "https://api.eia.gov/v2/petroleum/pri/spt/data/"
SERIES_ID = "RWTC"  # Cushing, OK WTI Spot Price FOB
LOOKBACK_DAYS = 365
REQUEST_TIMEOUT = 30  # 초


def log_result(status: str, message: str, rows: int = 0) -> None:
    """실행 결과를 collection_log.csv에 1행 추가한다."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    new_file = not os.path.exists(LOG_FILE)
    with open(LOG_FILE, "a", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        if new_file:
            writer.writerow(["timestamp", "source", "status", "rows", "message"])
        writer.writerow([
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            SOURCE_NAME, status, rows, message,
        ])


def collect() -> int:
    """EIA API에서 최근 1년 WTI 현물가격을 받아 CSV로 저장하고 저장 행수를 반환한다."""
    import pandas as pd

    # 1) API 키 확인
    load_dotenv()
    api_key = os.getenv("EIA_API_KEY")
    if not api_key:
        raise RuntimeError(
            "EIA_API_KEY를 찾을 수 없습니다. "
            "프로젝트 폴더에 .env 파일을 만들고 "
            ".env 파일에 EIA_API_KEY=발급받은_API_키 형식으로 저장하세요. "
            "(무료 발급: https://www.eia.gov/opendata/register.php)"
        )

    # 2) 요청 파라미터 (오늘 기준 365일 전 ~ 오늘, 일간, 오름차순)
    start_date = (datetime.now() - timedelta(days=LOOKBACK_DAYS)).strftime("%Y-%m-%d")
    params = {
        "api_key": api_key,
        "frequency": "daily",
        "data[0]": "value",
        "facets[series][]": SERIES_ID,
        "start": start_date,
        "sort[0][column]": "period",
        "sort[0][direction]": "asc",
        "length": 5000,
    }

    # 3) API 호출 (요청 실패 / 타임아웃을 각각 구분해 안내)
    try:
        resp = requests.get(API_URL, params=params, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
    except requests.exceptions.Timeout as e:
        raise TimeoutError(
            f"EIA API 응답이 {REQUEST_TIMEOUT}초 안에 오지 않았습니다(타임아웃). "
            "잠시 후 다시 실행하거나 인터넷 연결 상태를 확인하세요."
        ) from e
    except requests.exceptions.HTTPError as e:
        code = resp.status_code
        hint = "API 키가 올바른지 확인하세요." if code in (401, 403) else "요청 주소나 파라미터를 확인하세요."
        raise ConnectionError(
            f"EIA API 요청이 실패했습니다(HTTP {code}). {hint}"
        ) from e
    except requests.exceptions.RequestException as e:
        raise ConnectionError(
            f"EIA API에 연결하지 못했습니다. 인터넷 연결을 확인하세요. (원인: {e})"
        ) from e

    # 4) JSON 파싱 (파싱 실패를 별도 안내)
    try:
        payload = resp.json()
    except ValueError as e:
        raise ValueError(
            "EIA 응답을 JSON으로 해석하지 못했습니다. "
            "API가 점검 중이거나 응답 형식이 바뀌었을 수 있습니다."
        ) from e

    # 5) 데이터 유무 확인
    records = payload.get("response", {}).get("data", [])
    if not records:
        raise LookupError(
            "EIA 응답에 데이터가 없습니다. series 코드(RWTC)나 수집 기간을 확인하세요."
        )

    # 6) 컬럼 정리: date, series_name, value, source, collected_at
    df = pd.DataFrame(records)
    series_name = SERIES_ID
    if "series-description" in df.columns and df["series-description"].notna().any():
        series_name = str(df["series-description"].dropna().iloc[0])

    collected_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    out = pd.DataFrame({
        "date": df.get("period"),
        "series_name": series_name,
        "value": pd.to_numeric(df.get("value"), errors="coerce"),
        "source": SOURCE_LABEL,
        "collected_at": collected_at,
    })
    out = out.dropna(subset=["date"]).sort_values("date").reset_index(drop=True)

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    out.to_csv(OUTPUT_FILE, index=False, encoding="utf-8-sig")

    latest = out.iloc[-1]
    print(f"[OK] EIA WTI 수집 완료: {len(out)}행 저장 -> {OUTPUT_FILE}")
    print(f"     기간: {out.iloc[0]['date']} ~ {latest['date']}")
    print(f"     최신: {latest['date']}  {latest['value']} USD/bbl")
    return len(out)


def main() -> None:
    try:
        rows = collect()
        log_result("SUCCESS", f"{rows} rows saved", rows)
    except Exception as e:  # noqa: BLE001 - 모든 오류를 로그로 남긴다
        msg = f"{type(e).__name__}: {e}"
        print(f"[ERROR] EIA WTI 수집 실패 - {msg}")
        log_result("ERROR", msg)


if __name__ == "__main__":
    main()
