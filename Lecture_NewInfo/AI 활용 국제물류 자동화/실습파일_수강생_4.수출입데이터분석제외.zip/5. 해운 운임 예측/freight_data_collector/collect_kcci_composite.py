"""KCCI(Korea Container Composite Index) 종합지수 수집 스크립트.

자료원: KOBC(한국해양진흥공사) KCCI 공개 페이지
방식: requests 로 HTML 수신 후 pandas.read_html 로 표 파싱
출력: output/kcci_composite.csv
로그: output/collection_log.csv

비고: 사이트가 JavaScript 로 표를 렌더링하거나 구조를 변경하면 read_html 수집이
      실패할 수 있다. 이때는 가능한 원인을 출력·기록하며, 추후 Playwright/Selenium
      모듈로 교체한다. (아래 KCCI_URL / TARGET_INDEX_KEYWORDS 변수만 조정하면 대응 가능)
"""

import csv
import os
import re
from datetime import datetime
from io import StringIO

import requests

# ---- 자료원 설정 (변경 시 이 변수만 수정한다) ----------------------------------
KCCI_URL = "https://kobc.or.kr/ebz/shippinginfo/kcci/gridList.do?mId=0304000000"
TARGET_INDEX_KEYWORDS = ["Comprehensive Index", "KCCI", "종합지수"]
# --------------------------------------------------------------------------------

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
LOG_FILE = os.path.join(OUTPUT_DIR, "collection_log.csv")
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "kcci_composite.csv")
SOURCE_NAME = "kcci_composite"
SOURCE_LABEL = "KOBC KCCI"
ROUTE_LABEL = "KCCI Composite"
REQUEST_TIMEOUT = 30
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0 Safari/537.36"
    )
}


def log_result(status: str, message: str, rows: int = 0) -> None:
    """실행 결과를 collection_log.csv에 1행 추가한다."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    new_file = not os.path.exists(LOG_FILE)
    with open(LOG_FILE, "a", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        if new_file:
            writer.writerow(["timestamp", "source", "status", "rows", "message"])
        writer.writerow([
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            SOURCE_NAME, status, rows, message,
        ])


def clean_change_value(raw: str):
    """'197(7.95%)' 형태에서 괄호 앞 숫자(197)만 추출한다. 부호(-)는 유지한다."""
    if raw is None:
        return None
    text = str(raw).strip()
    head = text.split("(")[0]  # 괄호 앞 부분
    m = re.search(r"-?\d[\d,]*\.?\d*", head)
    if not m:
        return None
    return m.group(0).replace(",", "")


def extract_number(raw: str):
    """문자열에서 첫 숫자(소수/콤마 포함)를 추출한다."""
    if raw is None:
        return None
    m = re.search(r"-?\d[\d,]*\.?\d*", str(raw))
    return m.group(0).replace(",", "") if m else None


def find_publish_date(html_text: str, table) -> str:
    """발행일을 표 또는 페이지 전체 텍스트에서 추정한다. (YYYY-MM-DD 정규화)"""
    candidates = " ".join(str(v) for v in table.values.ravel().tolist()) + " " + html_text
    m = re.search(r"(20\d{2})[.\-/년\s]+(\d{1,2})[.\-/월\s]+(\d{1,2})", candidates)
    if m:
        y, mo, d = m.group(1), int(m.group(2)), int(m.group(3))
        return f"{y}-{mo:02d}-{d:02d}"
    return ""


def pick_target_row(table):
    """키워드가 포함된 행에서 종합지수·전주대비를 라벨 역전에 견고하게 추출한다.
    - 종합지수: 행 내 숫자 셀(백분율 제외) 중 절댓값이 가장 큰 값.
    - 전주대비: '%' 또는 '(' 가 포함된 셀의 괄호 앞 숫자(없으면 미상).
    표의 셀 순서가 바뀌어도(예: 선두에 무관한 '100' 이 추가되어도) 종합지수를
    올바르게 집어낸다.
    """
    for _, row in table.iterrows():
        cells = [str(v) for v in row.tolist()]
        joined = " ".join(cells)
        if any(kw.lower() in joined.lower() for kw in TARGET_INDEX_KEYWORDS):
            change_value = None
            for c in cells:
                # 전주대비는 '398(11.88%)' 처럼 괄호와 % 가 함께 있는 셀이다.
                # Weight 의 '100%' (괄호 없음)는 제외한다.
                if "(" in c and "%" in c:
                    cv = clean_change_value(c)
                    if cv is not None:
                        change_value = cv
                        break
            best = None
            for c in cells:
                if "%" in c or "(" in c:   # 비율/증감 셀 제외
                    continue
                v = extract_number(c)
                if v is None:
                    continue
                try:
                    fv = abs(float(v))
                except ValueError:
                    continue
                if best is None or fv > best[0]:
                    best = (fv, v)
            index_value = best[1] if best else None
            return index_value, change_value
    return None, None


def collect() -> int:
    """KCCI 종합지수를 수집해 CSV로 저장하고 저장 행수를 반환한다."""
    import pandas as pd

    # 1) 페이지 수신 (네트워크/차단 오류를 구분해 안내)
    try:
        resp = requests.get(KCCI_URL, headers=HEADERS, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
    except requests.exceptions.Timeout as e:
        raise TimeoutError(
            f"KOBC 페이지 응답이 {REQUEST_TIMEOUT}초 안에 오지 않았습니다(타임아웃). "
            "잠시 후 다시 시도하거나 네트워크 상태를 확인하세요."
        ) from e
    except requests.exceptions.HTTPError as e:
        raise ConnectionError(
            f"KOBC 페이지 요청이 실패했습니다(HTTP {resp.status_code}). "
            "접속이 차단되었거나 URL이 변경되었을 수 있습니다."
        ) from e
    except requests.exceptions.RequestException as e:
        raise ConnectionError(
            f"KOBC 페이지에 연결하지 못했습니다. 네트워크 또는 접속 차단을 확인하세요. (원인: {e})"
        ) from e

    resp.encoding = resp.apparent_encoding or "utf-8"
    html_text = resp.text

    # 2) 표 파싱 (표가 없으면 가능한 원인을 안내)
    try:
        tables = pd.read_html(StringIO(html_text))
    except ValueError as e:
        raise ValueError(
            "페이지에서 HTML 표(<table>)를 찾지 못했습니다. 가능한 원인:\n"
            "  1) 표가 JavaScript 로 렌더링되어 requests/read_html 로는 보이지 않음\n"
            "  2) 사이트 URL 또는 표 구조가 변경됨 (KCCI_URL 확인 필요)\n"
            "  3) 접속 차단 또는 네트워크 문제로 정상 페이지가 수신되지 않음\n"
            "  -> 해결: KCCI_URL 재확인 또는 Playwright/Selenium 수집으로 전환"
            f" (원본 오류: {e})"
        ) from e

    if not tables:
        raise ValueError(
            "표를 찾지 못했습니다(빈 결과). 가능한 원인: "
            "(1) JavaScript 렌더링, (2) URL/표 구조 변경, (3) 접속 차단/네트워크 문제."
        )

    # 3) 키워드가 포함된 표 우선, 없으면 가장 큰 표 사용
    target_table = None
    for t in tables:
        joined = " ".join(str(v) for v in t.values.ravel().tolist())
        if any(kw.lower() in joined.lower() for kw in TARGET_INDEX_KEYWORDS):
            target_table = t
            break
    if target_table is None:
        target_table = max(tables, key=len)

    index_value, change_value = pick_target_row(target_table)
    publish_date = find_publish_date(html_text, target_table)

    if index_value is None:
        raise LookupError(
            "표는 찾았으나 종합지수(Comprehensive Index) 값을 추출하지 못했습니다. "
            "TARGET_INDEX_KEYWORDS 또는 표 구조를 확인하세요."
        )

    # 4) 컬럼 정리: publish_date, route, index_value, change_value, source, collected_at
    collected_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    out = pd.DataFrame([{
        "publish_date": publish_date,
        "route": ROUTE_LABEL,
        "index_value": index_value,
        "change_value": change_value,
        "source": SOURCE_LABEL,
        "collected_at": collected_at,
    }])

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    out.to_csv(OUTPUT_FILE, index=False, encoding="utf-8-sig")

    print(f"[OK] KCCI 종합지수 수집 완료 -> {OUTPUT_FILE}")
    print(f"     발행일: {publish_date or '미상'}  지수: {index_value}  전주대비: {change_value}")
    return len(out)


def main() -> None:
    try:
        rows = collect()
        log_result("SUCCESS", f"{rows} rows saved", rows)
    except Exception as e:  # noqa: BLE001 - 모든 오류를 로그로 남긴다
        msg = f"{type(e).__name__}: {e}"
        print(f"[ERROR] KCCI 종합지수 수집 실패 - {msg}")
        log_result("ERROR", msg)


if __name__ == "__main__":
    main()
