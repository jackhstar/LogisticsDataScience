"""KOBC(한국해양진흥공사) 주간 통합 보고서(Weekly Focus) PDF 수집 스크립트.

처리 흐름 (KOBC eGov 게시판 실제 동작 기준):
  1) 목록 페이지(list.do)를 받아 세션 쿠키를 얻고, 최신 글의 조회 파라미터(data-keyset)를 추출한다.
  2) 상세 페이지는 view.do 로 POST 해야 한다. (목록 링크 onclick=req.post(this))
  3) 상세 HTML 의 fn_egov_downFile('atchFileId','fileSn') 에서 첨부파일 식별자를 추출한다.
  4) 다운로드 카운팅(saveProc.do)을 먼저 호출해야 세션이 인증되어 FileDown.do 가 PDF 를 반환한다.
  5) FileDown.do 로 PDF 를 받아 output/kobc_focus_latest.pdf 로 저장한다.
  6) 메타정보를 output/kobc_focus_meta.csv 에 저장한다.

방침:
  - requests, pandas 만 사용한다. (BeautifulSoup 미사용 — 링크/식별자는 정규식으로 추출)
  - 이번 단계에서는 PDF 본문을 추출하지 않는다.
  - 향후 pdfplumber / pymupdf 로 본문 요약을 붙일 수 있도록 함수를 분리해 둔다.
  - 실패 시 가능한 원인을 출력하고 output/collection_log.csv 에 기록한다.
"""

import csv
import html as html_lib
import os
import re
from datetime import datetime

import requests

# ---- 자료원 설정 (변경 시 이 변수만 수정한다) ----------------------------------
BASE = "https://www.kobc.or.kr"
CONTEXT = "/ebz"
SITE_CODE = "shippinginfo"
LIST_URL = f"{BASE}{CONTEXT}/shippinginfo/reportWeekly/list.do?mId=0202000000"
VIEW_URL = f"{BASE}{CONTEXT}/shippinginfo/reportWeekly/view.do?mId=0202000000"
LOG_SAVE_URL = f"{BASE}{CONTEXT}/common/file/download/log/saveProc.do"
FILEDOWN_URL = f"{BASE}{CONTEXT}/cmm/fms/FileDown.do"
# 상세 진입에 필요한 조회 파라미터 키 (data-keyset 안에 들어 있음)
KEYSET_FIELDS = ["crtrYmd", "rpppFileClssCd", "regPrdClssCd", "rpppFileSn"]
# --------------------------------------------------------------------------------

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
LOG_FILE = os.path.join(OUTPUT_DIR, "collection_log.csv")
PDF_FILE = os.path.join(OUTPUT_DIR, "kobc_focus_latest.pdf")
META_FILE = os.path.join(OUTPUT_DIR, "kobc_focus_meta.csv")
SOURCE_NAME = "kobc_focus"
SOURCE_LABEL = "KOBC Weekly Report"
REQUEST_TIMEOUT = 30
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0 Safari/537.36"
    )
}

CAUSES = (
    "가능한 원인:\n"
    "  1) 목록/상세 페이지 구조가 변경됨 (data-keyset 또는 fn_egov_downFile 패턴 확인 필요)\n"
    "  2) 링크/식별자가 JavaScript 로 생성되어 requests 로는 보이지 않음\n"
    "  3) 접속 차단, 사이트 점검, 네트워크 문제로 정상 페이지가 수신되지 않음\n"
    "  -> 해결: 상단 URL/패턴 재확인 또는 Playwright/Selenium 수집으로 전환"
)


# ---- 공통 유틸 -----------------------------------------------------------------
def log_result(status: str, message: str, rows: int = 0) -> None:
    """실행 결과를 collection_log.csv에 1행 추가한다."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    new_file = not os.path.exists(LOG_FILE)
    with open(LOG_FILE, "a", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        if new_file:
            writer.writerow(["timestamp", "source", "status", "rows", "message"])
        writer.writerow([
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            SOURCE_NAME, status, rows, message,
        ])


def make_session() -> requests.Session:
    """공통 헤더가 설정된 requests 세션을 만든다. (쿠키 유지)"""
    s = requests.Session()
    s.headers.update(HEADERS)
    return s


def http_get(session: requests.Session, url: str, **kwargs) -> requests.Response:
    """GET 요청. 네트워크/차단 오류를 구분해 안내한다."""
    return _request(session, "GET", url, **kwargs)


def http_post(session: requests.Session, url: str, **kwargs) -> requests.Response:
    """POST 요청. 네트워크/차단 오류를 구분해 안내한다."""
    return _request(session, "POST", url, **kwargs)


def _request(session, method, url, **kwargs):
    kwargs.setdefault("timeout", REQUEST_TIMEOUT)
    try:
        resp = session.request(method, url, **kwargs)
        resp.raise_for_status()
        return resp
    except requests.exceptions.Timeout as e:
        raise TimeoutError(
            f"KOBC 응답이 {REQUEST_TIMEOUT}초 안에 오지 않았습니다(타임아웃). "
            "잠시 후 다시 시도하거나 네트워크 상태를 확인하세요."
        ) from e
    except requests.exceptions.HTTPError as e:
        code = getattr(e.response, "status_code", "?")
        raise ConnectionError(
            f"KOBC 요청이 실패했습니다(HTTP {code}). 접속 차단 또는 URL 변경을 확인하세요."
        ) from e
    except requests.exceptions.RequestException as e:
        raise ConnectionError(
            f"KOBC 에 연결하지 못했습니다. 네트워크 또는 접속 차단을 확인하세요. (원인: {e})"
        ) from e


def normalize_date(value: str) -> str:
    """'20260608' 또는 '2026-06-08' -> 'YYYY-MM-DD' 로 정규화한다."""
    if not value:
        return ""
    m = re.search(r"(20\d{2})\D?(\d{2})\D?(\d{2})", value)
    return f"{m.group(1)}-{m.group(2)}-{m.group(3)}" if m else value


# ---- 1) 목록 -> 최신 글 조회 파라미터 ------------------------------------------
def parse_latest_item(list_html: str):
    """목록 HTML에서 최신(첫 번째) 글의 (keyset dict, title)을 반환한다."""
    m = re.search(
        r'<a\b[^>]*data-keyset="([^"]*)"[^>]*>(.*?)</a>',
        list_html,
        flags=re.IGNORECASE | re.DOTALL,
    )
    if not m:
        raise LookupError("목록 페이지에서 글 항목(data-keyset)을 찾지 못했습니다.\n" + CAUSES)

    keyset_raw = html_lib.unescape(m.group(1))
    title = re.sub(r"<[^>]+>", "", m.group(2)).strip()
    keyset = dict(re.findall(r"'(\w+)'\s*:\s*'([^']*)'", keyset_raw))
    keyset = {k: v for k, v in keyset.items() if k in KEYSET_FIELDS}

    if not keyset:
        raise LookupError("글 항목에서 조회 파라미터를 추출하지 못했습니다.\n" + CAUSES)
    return keyset, title


# ---- 2) 상세 페이지 (view.do POST) ---------------------------------------------
def get_detail_html(session: requests.Session, keyset: dict) -> str:
    """view.do 에 keyset 을 POST 해 상세 HTML 을 반환한다."""
    resp = http_post(session, VIEW_URL, data=keyset, headers={"Referer": LIST_URL})
    resp.encoding = resp.apparent_encoding or "utf-8"
    return resp.text


# ---- 3) 상세 -> 첨부파일 식별자 ------------------------------------------------
def parse_download_ids(detail_html: str):
    """상세 HTML 의 fn_egov_downFile('atchFileId','fileSn') 에서 식별자를 추출한다."""
    m = re.search(
        r"fn_egov_downFile\(\s*'([^']+)'\s*,\s*'([^']+)'\s*\)",
        detail_html,
    )
    if not m:
        raise LookupError("상세 페이지에서 PDF 다운로드 식별자를 찾지 못했습니다.\n" + CAUSES)
    return m.group(1), m.group(2)


# ---- 4~5) PDF 다운로드 ---------------------------------------------------------
def download_pdf(session: requests.Session, atch_file_id: str, file_sn: str, save_path: str):
    """다운로드 카운팅 후 FileDown.do 에서 PDF 를 받아 저장한다. (바이트수, pdf_url 반환)"""
    # 4) 다운로드 카운팅 — 이 호출이 선행되어야 FileDown 이 PDF 를 반환한다.
    http_post(
        session,
        LOG_SAVE_URL,
        data={"atchFileId": atch_file_id, "fileSn": file_sn, "siteCode": SITE_CODE},
        headers={"Referer": VIEW_URL},
    )

    # 5) 실제 다운로드
    params = {"atchFileId": atch_file_id, "fileSn": file_sn}
    resp = http_get(session, FILEDOWN_URL, params=params, headers={"Referer": VIEW_URL})
    content = resp.content
    if not content:
        raise ValueError("PDF 응답 본문이 비어 있습니다. 다운로드 식별자 또는 접속 상태를 확인하세요.")
    if content[:4] != b"%PDF":
        raise ValueError(
            "다운로드 결과가 PDF 가 아닙니다(오류 페이지일 수 있음). "
            "카운팅 호출/세션 또는 식별자를 확인하세요."
        )

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    with open(save_path, "wb") as f:
        f.write(content)
    pdf_url = f"{FILEDOWN_URL}?atchFileId={atch_file_id}&fileSn={file_sn}"
    return len(content), pdf_url


# ---- (향후 단계) PDF 본문 요약 -------------------------------------------------
def summarize_pdf(pdf_path: str):
    """[미구현] 추후 pdfplumber 또는 pymupdf로 본문을 추출/요약하는 자리.

    이번 단계에서는 본문을 추출하지 않는다. 향후 이 함수만 구현하면
    collect() 흐름에 손쉽게 끼워 넣을 수 있다.
    """
    return None


# ---- 6) 메타 저장 --------------------------------------------------------------
def save_meta(meta: dict) -> None:
    """메타정보 1행을 output/kobc_focus_meta.csv에 저장한다."""
    import pandas as pd

    cols = ["title", "publish_date", "source_url", "pdf_url", "saved_path", "collected_at"]
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    pd.DataFrame([{c: meta.get(c, "") for c in cols}]).to_csv(
        META_FILE, index=False, encoding="utf-8-sig"
    )


# ---- 오케스트레이션 ------------------------------------------------------------
def collect() -> int:
    """목록 -> 상세 -> PDF 다운로드 -> 메타 저장 흐름을 수행하고 저장 행수를 반환한다."""
    session = make_session()

    # 1) 목록 (세션 쿠키 획득 + 최신 글 파라미터)
    list_resp = http_get(session, LIST_URL)
    list_resp.encoding = list_resp.apparent_encoding or "utf-8"
    keyset, title = parse_latest_item(list_resp.text)
    publish_date = normalize_date(keyset.get("crtrYmd", ""))

    # 2) 상세
    detail_html = get_detail_html(session, keyset)

    # 3) 첨부 식별자
    atch_file_id, file_sn = parse_download_ids(detail_html)

    # 4~5) PDF 다운로드
    size, pdf_url = download_pdf(session, atch_file_id, file_sn, PDF_FILE)

    # 6) 메타 저장
    collected_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    meta = {
        "title": title or "KOBC Weekly Report",
        "publish_date": publish_date,
        "source_url": VIEW_URL,
        "pdf_url": pdf_url,
        "saved_path": PDF_FILE,
        "collected_at": collected_at,
    }
    save_meta(meta)

    print(f"[OK] KOBC Weekly PDF 수집 완료 -> {PDF_FILE} ({size:,} bytes)")
    print(f"     제목: {meta['title']}  발행일: {publish_date or '미상'}")
    return 1


def main() -> None:
    try:
        rows = collect()
        log_result("SUCCESS", f"{rows} pdf saved", rows)
    except Exception as e:  # noqa: BLE001 - 모든 오류를 로그로 남긴다
        msg = f"{type(e).__name__}: {e}"
        print(f"[ERROR] KOBC Weekly 수집 실패 - {msg}")
        log_result("ERROR", msg)


if __name__ == "__main__":
    main()
