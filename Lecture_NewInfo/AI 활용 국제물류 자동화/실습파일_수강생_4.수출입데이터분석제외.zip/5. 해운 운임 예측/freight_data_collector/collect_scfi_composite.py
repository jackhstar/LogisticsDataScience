"""SCFI(Shanghai Containerized Freight Index) 종합지수 수집 스크립트.

자료원: forwarder.kr SCFI 페이지의 인라인 차트 데이터(const chartData = { ... })
방식: requests 로 HTML 을 받아 chartData 의 지정 기간(기본 '1year') labels/data 를 정규식으로 파싱
출력: output/scfi_composite.csv
로그: output/collection_log.csv

페이지 내 데이터 형태(실제 확인):
  const chartData = {
      '1month': { labels: ['2026-05-15', ...], data: [2140.66, ...] },
      '1year':  { labels: ['2025-06-13', ...], data: [2088.24, ...] },
      ...
  };
  (키는 작은따옴표, labels/data 는 따옴표 없는 키, 날짜는 'YYYY-MM-DD')

비고: 수집 실패 시 빈 파일을 만들지 않고 오류 사유를 출력·기록한다.
"""

import csv
import os
import re
from datetime import datetime

import requests

# ---- 자료원 설정 (변경 시 이 변수만 수정한다) ----------------------------------
SCFI_PAGE_URL = "https://www.forwarder.kr/freight/index/scfi"
CHART_PERIOD_KEY = "1year"          # chartData 의 기간 키 (1month/3months/6months/1year/3years/5years/all)
ROUTE_NAME = "SCFI Composite"
SOURCE_LABEL = "Forwarder.kr SCFI Composite"
# --------------------------------------------------------------------------------

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
LOG_FILE = os.path.join(OUTPUT_DIR, "collection_log.csv")
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "scfi_composite.csv")
SOURCE_NAME = "scfi_composite"
REQUEST_TIMEOUT = 30
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0 Safari/537.36"
    )
}


def log_result(status: str, message: str, rows: int = 0) -> None:
    """실행 결과를 collection_log.csv에 1행 추가한다."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    new_file = not os.path.exists(LOG_FILE)
    with open(LOG_FILE, "a", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        if new_file:
            writer.writerow(["timestamp", "source", "status", "rows", "message"])
        writer.writerow([
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            SOURCE_NAME, status, rows, message,
        ])


def fetch_html() -> str:
    """SCFI 페이지 HTML 을 받아 문자열로 반환한다. (네트워크/차단 오류를 구분해 안내)"""
    try:
        resp = requests.get(SCFI_PAGE_URL, headers=HEADERS, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
    except requests.exceptions.Timeout as e:
        raise TimeoutError(
            f"forwarder.kr 응답이 {REQUEST_TIMEOUT}초 안에 오지 않았습니다(타임아웃). "
            "잠시 후 다시 시도하거나 네트워크 상태를 확인하세요."
        ) from e
    except requests.exceptions.HTTPError as e:
        code = getattr(e.response, "status_code", "?")
        raise ConnectionError(
            f"forwarder.kr 요청이 실패했습니다(HTTP {code}). 접속 차단 또는 URL 변경을 확인하세요."
        ) from e
    except requests.exceptions.RequestException as e:
        raise ConnectionError(
            f"forwarder.kr 에 연결하지 못했습니다. 네트워크 또는 접속 차단을 확인하세요. (원인: {e})"
        ) from e
    resp.encoding = resp.apparent_encoding or "utf-8"
    return resp.text


def parse_chart_period(html_text: str, period_key: str):
    """chartData 에서 period_key 의 (labels, data) 리스트를 파싱해 반환한다."""
    # '<period_key>': { labels: [ ... ], data: [ ... ] }
    block = re.search(
        r"'" + re.escape(period_key) + r"'\s*:\s*\{\s*"
        r"labels\s*:\s*\[(?P<labels>.*?)\]\s*,\s*"
        r"data\s*:\s*\[(?P<data>.*?)\]\s*\}",
        html_text,
        flags=re.DOTALL,
    )
    if not block:
        raise LookupError(
            f"chartData 에서 '{period_key}' 기간 블록을 찾지 못했습니다. 가능한 원인:\n"
            "  1) 페이지 구조 변경 (chartData 변수명/형식 변경)\n"
            "  2) 차트 데이터가 JavaScript 로 동적 생성되어 HTML 에 없음\n"
            "  3) 접속 차단, 사이트 점검, 네트워크 문제\n"
            "  -> 해결: SCFI_PAGE_URL / CHART_PERIOD_KEY 재확인 또는 동적 렌더링 수집으로 전환"
        )

    labels = re.findall(r"'([^']*)'", block.group("labels"))
    data = re.findall(r"-?\d+\.?\d*", block.group("data"))

    if not labels or not data:
        raise ValueError(f"'{period_key}' 의 labels 또는 data 가 비어 있습니다. 페이지 형식을 확인하세요.")
    if len(labels) != len(data):
        raise ValueError(
            f"labels({len(labels)})와 data({len(data)}) 개수가 일치하지 않습니다. 페이지 형식을 확인하세요."
        )
    return labels, data


def collect() -> int:
    """SCFI 1년치 데이터를 수집해 CSV로 저장하고 저장 행수를 반환한다."""
    import pandas as pd

    html_text = fetch_html()
    labels, values = parse_chart_period(html_text, CHART_PERIOD_KEY)

    # CHART_PERIOD_KEY='1year' 자체가 최근 1년 주간 데이터이다. (요구사항 8 충족)
    collected_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    out = pd.DataFrame({
        "date": labels,
        "route": ROUTE_NAME,
        "scfi_value": pd.to_numeric(pd.Series(values), errors="coerce"),
        "source": SOURCE_LABEL,
        "collected_at": collected_at,
    })
    out = out.dropna(subset=["scfi_value"]).sort_values("date").reset_index(drop=True)

    if out.empty:
        raise ValueError("유효한 SCFI 수치가 없습니다. (빈 파일을 만들지 않음)")

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    out.to_csv(OUTPUT_FILE, index=False, encoding="utf-8-sig")

    print(f"[OK] SCFI 종합지수 수집 완료: {len(out)}행 저장 -> {OUTPUT_FILE}")
    print(f"     기간: {out.iloc[0]['date']} ~ {out.iloc[-1]['date']}")
    print(f"     최신: {out.iloc[-1]['date']}  {out.iloc[-1]['scfi_value']}")
    return len(out)


def main() -> None:
    try:
        rows = collect()
        log_result("SUCCESS", f"{rows} rows saved", rows)
    except Exception as e:  # noqa: BLE001 - 모든 오류를 로그로 남긴다
        msg = f"{type(e).__name__}: {e}"
        print(f"[ERROR] SCFI 종합지수 수집 실패 - {msg}")
        log_result("ERROR", msg)


if __name__ == "__main__":
    main()
