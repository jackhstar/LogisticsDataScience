"""해운·물류 시장자료 병합 스크립트.

처리 내용:
  1) output 폴더의 eia_wti.csv, kcci_composite.csv, scfi_composite.csv 를 읽는다.
  2) 날짜(date) 기준으로 병합 가능한 자료를 outer-merge 한다.
  3) KOBC 주간 통합 시황 리포트 PDF 메타(kobc_focus_meta.csv)는 시계열에 합치지 않고 별도 표로 유지한다.
  4) 병합 결과를 output/freight_market_dataset.csv 로 저장한다.
  5) 자료별 최신 날짜·행 수·결측 여부를 output/data_quality_report.csv 로 저장한다.
  6) 일부 자료가 없어 병합이 불가능해도 각 파일의 수집 상태를 요약 출력한다.
"""

import csv
import os
from datetime import datetime

import pandas as pd

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
LOG_FILE = os.path.join(OUTPUT_DIR, "collection_log.csv")
DATASET_FILE = os.path.join(OUTPUT_DIR, "freight_market_dataset.csv")
QUALITY_FILE = os.path.join(OUTPUT_DIR, "data_quality_report.csv")
SOURCE_NAME = "merge"

# ---- 병합 대상(시계열) 자료 정의 ------------------------------------------------
# rename: 원본 컬럼 -> 병합 후 컬럼명
TIMESERIES_SOURCES = [
    {
        "name": "eia_wti",
        "file": "eia_wti.csv",
        "date_col": "date",
        "rename": {"value": "wti_value"},
    },
    {
        "name": "scfi_composite",
        "file": "scfi_composite.csv",
        "date_col": "date",
        "rename": {"scfi_value": "scfi_value"},
    },
    {
        "name": "kcci_composite",
        "file": "kcci_composite.csv",
        "date_col": "publish_date",
        "rename": {"index_value": "kcci_index_value", "change_value": "kcci_change_value"},
    },
]
# KOBC PDF 메타는 별도 표로 유지 (시계열 병합 대상 아님)
KOBC_META = {"name": "kobc_focus", "file": "kobc_focus_meta.csv", "date_col": "publish_date"}


def log_result(status: str, message: str, rows: int = 0) -> None:
    """실행 결과를 collection_log.csv에 1행 추가한다."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    new_file = not os.path.exists(LOG_FILE)
    with open(LOG_FILE, "a", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        if new_file:
            writer.writerow(["timestamp", "source", "status", "rows", "message"])
        writer.writerow([
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            SOURCE_NAME, status, rows, message,
        ])


def load_source(spec: dict) -> dict:
    """자료 1건을 읽어 상태 dict 를 반환한다.

    반환: {name, file, status, rows, latest_date, has_missing, df}
      status: loaded | missing | empty | error
    """
    info = {
        "name": spec["name"], "file": spec["file"], "status": "missing",
        "rows": 0, "latest_date": "", "has_missing": "", "df": None,
    }
    path = os.path.join(OUTPUT_DIR, spec["file"])
    if not os.path.exists(path):
        return info
    try:
        df = pd.read_csv(path)
    except Exception as e:  # noqa: BLE001
        info["status"] = "error"
        info["latest_date"] = f"read error: {type(e).__name__}"
        return info

    if df.empty:
        info["status"] = "empty"
        return info

    info["status"] = "loaded"
    info["rows"] = len(df)
    info["has_missing"] = bool(df.isna().any().any())

    date_col = spec.get("date_col")
    if date_col and date_col in df.columns:
        dates = pd.to_datetime(df[date_col], errors="coerce").dropna()
        if not dates.empty:
            info["latest_date"] = dates.max().strftime("%Y-%m-%d")
    info["df"] = df
    return info


def build_timeseries(spec: dict, df: pd.DataFrame) -> pd.DataFrame:
    """시계열 자료를 [date, <rename된 값 컬럼들>] 형태로 표준화한다."""
    cols = {}
    cols["date"] = pd.to_datetime(df[spec["date_col"]], errors="coerce").dt.strftime("%Y-%m-%d")
    for src_col, new_col in spec["rename"].items():
        cols[new_col] = pd.to_numeric(df[src_col], errors="coerce") if src_col in df.columns else None
    out = pd.DataFrame(cols).dropna(subset=["date"])
    # 같은 날짜 중복 시 마지막 값 유지
    out = out.drop_duplicates(subset=["date"], keep="last")
    return out


def merge_timeseries(loaded: list) -> pd.DataFrame:
    """로드된 시계열 자료들을 date 기준 outer-merge 한다."""
    merged = None
    for spec, info in loaded:
        if info["status"] != "loaded":
            continue
        ts = build_timeseries(spec, info["df"])
        if ts.empty:
            continue
        merged = ts if merged is None else merged.merge(ts, on="date", how="outer")
    if merged is None:
        return pd.DataFrame(columns=["date"])
    return merged.sort_values("date").reset_index(drop=True)


def print_status_summary(statuses: list, merged_rows: int) -> None:
    """각 파일의 수집 상태를 콘솔에 요약 출력한다. (요구사항 6)"""
    print("\n=== 자료 수집 상태 요약 ===")
    label = {
        "loaded": "정상", "missing": "파일 없음", "empty": "빈 파일", "error": "읽기 오류",
    }
    for info in statuses:
        miss = "" if info["has_missing"] == "" else (" / 결측 있음" if info["has_missing"] else " / 결측 없음")
        latest = info["latest_date"] or "-"
        print(
            f"  - {info['name']:<16} {label.get(info['status'], info['status']):<8} "
            f"행수={info['rows']:<4} 최신일자={latest}{miss}"
        )
    print(f"  => 병합 시계열 행수: {merged_rows}")


def main() -> None:
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # 1) 시계열 3종 + KOBC 메타 로드
    loaded = [(spec, load_source(spec)) for spec in TIMESERIES_SOURCES]
    kobc_info = load_source(KOBC_META)
    all_status = [info for _, info in loaded] + [kobc_info]

    # 2) 병합
    merged = merge_timeseries(loaded)
    merged_ok = not merged.empty

    # 4) 병합 결과 저장 (병합 가능한 자료가 하나라도 있을 때만 저장)
    if merged_ok:
        merged.to_csv(DATASET_FILE, index=False, encoding="utf-8-sig")
        print(f"[OK] 병합 데이터셋 저장 -> {DATASET_FILE} ({len(merged)}행, {len(merged.columns)}열)")
    else:
        print("[경고] 병합 가능한 시계열 자료가 없어 freight_market_dataset.csv 를 생성하지 않았다.")

    # 3) KOBC PDF 메타는 별도 표로 유지 — 상태만 안내 (이미 kobc_focus_meta.csv 로 존재)
    if kobc_info["status"] == "loaded":
        print(f"[정보] KOBC PDF 메타는 별도 표로 유지: {KOBC_META['file']} ({kobc_info['rows']}행)")

    # 5) 데이터 품질 리포트 저장
    quality_rows = [{
        "source": info["name"],
        "file": info["file"],
        "status": info["status"],
        "row_count": info["rows"],
        "latest_date": info["latest_date"],
        "has_missing": info["has_missing"],
    } for info in all_status]
    pd.DataFrame(quality_rows).to_csv(QUALITY_FILE, index=False, encoding="utf-8-sig")
    print(f"[OK] 데이터 품질 리포트 저장 -> {QUALITY_FILE}")

    # 6) 수집 상태 요약 출력
    print_status_summary(all_status, len(merged) if merged_ok else 0)

    # 로그 기록
    status = "SUCCESS" if merged_ok else "PARTIAL"
    log_result(status, f"merged {len(merged)} rows" if merged_ok else "no mergeable timeseries", len(merged) if merged_ok else 0)


if __name__ == "__main__":
    main()
