@echo off
chcp 65001 >nul
REM ============================================================
REM  위 run_freight_bypython.bat 를 매일 07:00 자동 실행하도록
REM  Windows 작업 스케줄러에 등록한다. (관리자 권한 권장)
REM  시간 변경: /ST 07:00 부분을 원하는 HH:MM 으로 수정
REM ============================================================
schtasks /Create /TN "FreightMarketBypython" /TR "\"C:\logistics\claude\freight_data_collector\run_freight_bypython.bat\"" /SC DAILY /ST 07:00 /F
if "%ERRORLEVEL%"=="0" (
  echo [완료] 등록됨. 확인:  schtasks /Query /TN "FreightMarketBypython"
) else (
  echo [오류] 등록 실패. 관리자 권한 cmd 에서 다시 실행하세요.
)
pause
