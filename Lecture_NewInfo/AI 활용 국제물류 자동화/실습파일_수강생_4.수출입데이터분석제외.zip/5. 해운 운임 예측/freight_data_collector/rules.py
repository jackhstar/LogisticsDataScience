# -*- coding: utf-8 -*-
"""규칙 기반 분석 문장 생성 모듈.

LLM 없이, 오직 숫자 변화율을 임계값 규칙에 대입해 한국어 분석 문장을
'찍어내는' 모듈이다. run_market_workflowbypython.py 가 계산한 컨텍스트
(dict)를 입력받아 리포트 각 절의 문장 리스트를 반환한다.

설계 원칙
  - 모든 문장은 입력 숫자에서 결정론적으로 생성된다(같은 입력 → 같은 문장).
  - 등급 판정은 단일 임계표(grade_pct)로 통일한다.
"""
from __future__ import annotations


# ---- 공통 포맷 헬퍼 -----------------------------------------------------------
def fmt(v, nd: int = 2) -> str:
    """숫자를 천단위 콤마 + 소수 nd자리로 포맷한다. None은 'N/A'."""
    if v is None:
        return "N/A"
    try:
        f = float(v)
    except (TypeError, ValueError):
        return str(v)
    if nd == 0 or f == int(f):
        return f"{int(round(f)):,}"
    return f"{f:,.{nd}f}"


def signed(v, nd: int = 2) -> str:
    """부호를 붙인 숫자 문자열(+/-)."""
    if v is None:
        return "N/A"
    f = float(v)
    body = fmt(abs(f), nd)
    return f"+{body}" if f >= 0 else f"-{body}"


def arrow(pct) -> str:
    if pct is None:
        return "-"
    return "▲" if pct > 0 else ("▼" if pct < 0 else "-")


# ---- 변화율 → 등급 규칙 -------------------------------------------------------
# (하한 초과, 등급명) 내림차순. pct(%) 기준.
_GRADE_TABLE = [
    (10.0, "급등"),
    (3.0, "상승"),
    (1.0, "소폭 상승"),
    (-1.0, "보합"),
    (-3.0, "소폭 하락"),
    (-10.0, "하락"),
]


def grade_pct(pct) -> str:
    """변화율(%)을 7단계 등급 문자열로 변환한다."""
    if pct is None:
        return "판단 불가"
    for low, label in _GRADE_TABLE:
        if pct > low:
            return label
    return "급락"


def trend_word(pct) -> str:
    """방향성 단어(상승/하락/보합)."""
    if pct is None:
        return "판단 불가"
    if pct > 1.0:
        return "상승"
    if pct < -1.0:
        return "하락"
    return "보합"


# ---- 절별 문장 생성 -----------------------------------------------------------
def sec1_current(ctx: dict) -> str:
    """1. 운임 시장의 현재 수준."""
    s = ctx["scfi"]
    k = ctx.get("kcci") or {}
    w = ctx["wti"]
    parts = []

    g = grade_pct(s["wk_pct"])
    streak = s.get("up_streak", 0)
    streak_txt = f"이며 {streak}주 연속 상승세다" if streak >= 2 else "이다"
    parts.append(
        f"SCFI 복합지수는 {s['last_date']} 기준 {fmt(s['last'])}pt로, "
        f"직전 대비 {signed(s['wk_chg'])}pt({signed(s['wk_pct'],1)}%)의 {g} 흐름{streak_txt}. "
        f"이는 최근 1년 최고 {fmt(s['yr_high'])}pt, 최저 {fmt(s['yr_low'])}pt 구간에서 "
        f"고점 대비 {fmt(s['from_high_pct'],1)}% 수준이다."
    )
    if k.get("last") is not None:
        gk = grade_pct(k.get("wk_pct"))
        parts.append(
            f"KCCI 종합지수(Comprehensive Index)는 {k['last_date']} 기준 {fmt(k['last'],0)}pt로 "
            f"직전 대비 {signed(k.get('wk_chg'),0)}pt({signed(k.get('wk_pct'),1)}%)의 {gk}이다"
            f"(KOBC 표기 단위 pt 기준)."
        )
    gw = grade_pct(w["m_pct"])
    level = "90달러대 고유가" if w["last"] and w["last"] >= 90 else (
        "80달러대" if w["last"] and w["last"] >= 80 else "60~70달러대")
    parts.append(
        f"EIA WTI 현물은 {w['last_date']} 기준 {fmt(w['last'])}달러로 {level} 수준이며, "
        f"최근 30일 {signed(w['m_pct'],1)}%({grade_pct(w['m_pct'])})로 정리된다."
    )
    return " ".join(parts)


def sec2_trend(ctx: dict) -> str:
    """2. 최근 90일 방향성."""
    s = ctx["scfi"]
    w = ctx["wti"]
    return (
        f"SCFI 복합지수는 최근 90일 {signed(s['q_chg'])}pt({signed(s['q_pct'],1)}%)로 {grade_pct(s['q_pct'])}, "
        f"최근 30일 {signed(s['m_chg'])}pt({signed(s['m_pct'],1)}%)로 {grade_pct(s['m_pct'])}했다. "
        f"90일·30일 변화율을 비교하면 상승 속도는 "
        f"{'가팔라지는' if (s['m_pct'] or 0) > (s['q_pct'] or 0)/3 else '완만해지는'} 국면이다. "
        f"WTI는 최근 90일 기준 {signed(w['q_pct'],1)}%({grade_pct(w['q_pct'])}), "
        f"최근 30일 기준 {signed(w['m_pct'],1)}%({grade_pct(w['m_pct'])})다(기준 기간 정의에 따라 변화율은 달라질 수 있다). "
        f"방향성은 최근 30일 기준 운임과 "
        f"{'같은' if (w['m_pct'] or 0)*(s['m_pct'] or 0) > 0 else '반대'} 방향, 최근 90일 기준 "
        f"{'모두 상승' if (w['q_pct'] or 0) > 0 and (s['q_pct'] or 0) > 0 else ('모두 하락' if (w['q_pct'] or 0) < 0 and (s['q_pct'] or 0) < 0 else '엇갈린 방향')}이다."
    )


def sec3_outlook(ctx: dict) -> str:
    """3. 다음 분기 전망 — 모멘텀 조합 규칙."""
    s = ctx["scfi"]
    sm = s["m_pct"] or 0.0
    sq = s["q_pct"] or 0.0
    if sm >= 10:
        base = "강한 상승세가 이어지는 만큼 다음 분기 전반은 '상승 후 고운임 횡보'"
    elif sm >= 3:
        base = "완만한 상승 흐름을 고려하면 다음 분기는 '점진적 상승'"
    elif sm > -3:
        base = "보합권 흐름을 고려하면 다음 분기는 '횡보'"
    else:
        base = "최근 하락 전환을 고려하면 다음 분기는 '약세 내지 조정'"
    accel = "단기 상승 탄력이 3개월 평균을 웃돌아" if sm > sq / 3 else "단기 상승 탄력이 둔화되어"
    return (
        f"본 절은 공식 예측이 아니라 단순 수치 모멘텀 시나리오다. 규칙 기반 판정상 {base}에 가깝다. "
        f"SCFI 최근 30일 {signed(sm,1)}%, 최근 90일 {signed(sq,1)}% 기준 "
        f"{accel} 분기 전반의 방향은 {trend_word(sm)} 쪽이다. "
        f"다만 수요·공급, 지정학, 선복 공급, 항만 혼잡, 유류비, 선사 운임정책 등은 반영하지 않았으므로 "
        f"실제 전망으로 해석하지 않는다."
    )


def sec4_compare(ctx: dict) -> str:
    """4. SCFI vs KCCI 방향 비교."""
    s = ctx["scfi"]
    k = ctx.get("kcci") or {}
    if k.get("wk_pct") is None:
        return "KCCI 변화율 자료가 없어 두 지수의 방향 비교를 생략한다."
    sp, kp = s["wk_pct"] or 0.0, k["wk_pct"] or 0.0
    same = (sp > 0) == (kp > 0)
    rel = "같은 방향" if same else "엇갈린 방향"
    stronger = "KCCI" if abs(kp) > abs(sp) else "SCFI"
    return (
        f"두 지수는 {rel}이다. SCFI 주간 {signed(sp,1)}%, KCCI 주간 {signed(kp,1)}%로 "
        f"{'동반 ' + trend_word(sp) if same else '방향이 갈리며'}, 변동 폭은 {stronger}가 더 크다. "
        f"{'종합지수 차원에서는 동조 흐름' if same else '종합지수 차원에서 차별화가 진행 중'}으로 해석된다."
    )


def sec5_wti(ctx: dict) -> str:
    """5. WTI 유가가 운임·비용·협상력에 미치는 영향."""
    w = ctx["wti"]
    lvl = w["last"] or 0
    if lvl >= 90:
        cost = ("WTI 90달러대 고유가는 벙커유 비용 상승 압력으로 이어질 수 있다(다만 실제 벙커유가는 "
                "원유가 외에 정제마진·연료 종류·항만별 수급·황함유 규제·지역 스프레드에 따라 달라진다)")
        nego = ("일부 항로·스팟 시장에서는 고유가·할증료를 근거로 선사 측 협상력이 강화될 수 있으나, "
                "실제 협상력은 운임 레벨·선복 수급·계약/스팟 비중·항로 경쟁·성수기 여부에 좌우된다")
    elif lvl >= 75:
        cost = "WTI 70~80달러대는 연료비 부담이 중립~다소 높은 수준이다"
        nego = "유류할증 명분이 일부 유지되어 화주 협상력은 제한적이다"
    else:
        cost = "WTI 60~70달러대의 상대적 저유가는 연료비 부담을 완화한다"
        nego = "할증료 정당화 논리가 약해져 화주 협상력은 회복 여지가 있다"
    direction = (
        "최근 30일 유가가 상승해 비용 압력이 가중되는 방향"
        if (w["m_pct"] or 0) > 1 else
        ("최근 30일 유가가 하락해 비용 압력이 완화되는 방향" if (w["m_pct"] or 0) < -1
         else "최근 30일 유가가 보합으로 비용 압력은 중립")
    )
    return (
        f"{cost}. 또한 {nego}. 방향성 측면에서는 {direction}이며, "
        f"최근 90일 {signed(w['q_pct'],1)}%·최근 30일 {signed(w['m_pct'],1)}% 변화율이 이를 뒷받침한다."
    )


def summary_rows(ctx: dict) -> list:
    """요약 절(라벨, 문장) 리스트."""
    s = ctx["scfi"]
    w = ctx["wti"]
    k = ctx.get("kcci") or {}
    kcci_txt = (f", KCCI {fmt(k.get('last'),0)}pt({signed(k.get('wk_pct'),1)}%)"
                if k.get("last") is not None else "")
    return [
        ("현재", f"SCFI {fmt(s['last'])}pt({s['last_date']}, 주간 {signed(s['wk_pct'],1)}%, {grade_pct(s['wk_pct'])})"
                 f"{kcci_txt}, WTI {fmt(w['last'])}달러({grade_pct(w['m_pct'])})."),
        ("방향", f"SCFI 최근 90일 {signed(s['q_pct'],1)}%·최근 30일 {signed(s['m_pct'],1)}%, "
                 f"WTI 최근 90일 {signed(w['q_pct'],1)}%·최근 30일 {signed(w['m_pct'],1)}%."),
        ("전망", f"수치 모멘텀 규칙상(공식 전망 아님) 다음 분기 방향은 '{trend_word(s['m_pct'])}' 우위."),
        ("유의", "본 리포트의 문장은 LLM 해석이 아니라 변화율 임계 규칙으로 자동 생성된 결과이며, "
                 "정성 변수(지정학·공급 정상화·정책)는 반영되지 않는다."),
    ]


def build_sections(ctx: dict) -> dict:
    """리포트에 들어갈 모든 규칙 문장을 한 번에 생성한다."""
    return {
        "sec1": sec1_current(ctx),
        "sec2": sec2_trend(ctx),
        "sec3": sec3_outlook(ctx),
        "sec4": sec4_compare(ctx),
        "sec5": sec5_wti(ctx),
        "summary": summary_rows(ctx),
    }


# ====================================================================
# [캐시 말단 절단 방어용 패딩 — 삭제 금지]
# 일부 환경에서 스킬 등록(캐시) 시 rules.py 끝 수 바이트가 잘려
# SyntaxError('(' was never closed)가 발생하는 현상이 있다.
# 핵심 코드(build_sections)가 파일 맨 끝에 오지 않도록 여백을 둔다.
# 캐시가 끝 수십~수백 바이트를 잘라도 잘리는 것은 이 주석뿐이며
# 실제 코드는 온전히 유지된다.
# padding 01 ------------------------------------------------
# padding 02 ------------------------------------------------
# padding 03 ------------------------------------------------
# padding 04 ------------------------------------------------
# padding 05 ------------------------------------------------
# padding 06 ------------------------------------------------
# padding 07 ------------------------------------------------
# padding 08 ------------------------------------------------
# padding 09 ------------------------------------------------
# padding 10 ------------------------------------------------
# padding 11 ------------------------------------------------
# padding 12 ------------------------------------------------
# padding 13 ------------------------------------------------
# padding 14 ------------------------------------------------
# padding 15 ------------------------------------------------
# padding 16 ------------------------------------------------
# padding 17 ------------------------------------------------
# padding 18 ------------------------------------------------
# padding 19 ------------------------------------------------
# padding 20 ------------------------------------------------
# padding 21 ------------------------------------------------
# padding 22 ------------------------------------------------
# padding 23 ------------------------------------------------
# padding 24 ------------------------------------------------
# padding 25 ------------------------------------------------
# padding 26 ------------------------------------------------
# padding 27 ------------------------------------------------
# padding 28 ------------------------------------------------
# padding 29 ------------------------------------------------
# padding 30 ------------------------------------------------
# ===================== end of padding ===============================
