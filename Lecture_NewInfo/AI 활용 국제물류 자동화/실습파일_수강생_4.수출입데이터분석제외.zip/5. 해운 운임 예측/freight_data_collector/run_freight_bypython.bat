@echo off
chcp 65001 >nul
REM ============================================================
REM  freight-market-workflowbypython 자동 실행 배치
REM  수집 -> 병합 -> 규칙 기반 HTML 리포트 생성까지 한 번에 수행
REM  (인터넷이 되는 사용자 PC에서 실행해야 최신 데이터가 수집된다)
REM ============================================================

set "PROJECT=C:\logistics\claude\freight_data_collector"
set "SCRIPT=%PROJECT%\run_market_workflowbypython.py"
set "LOGDIR=%PROJECT%\output\scheduler_log"

if not exist "%LOGDIR%" mkdir "%LOGDIR%"

REM 로그 파일명 타임스탬프(YYYYMMDD_HHMM) - PowerShell 사용(로캘 무관)
for /f %%t in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmm"') do set "STAMP=%%t"
set "LOG=%LOGDIR%\run_%STAMP%.log"

REM -- Python 경로 확인 방법 --------------------------------------
REM  명령창(cmd)에서 다음을 실행해 python 이 PATH 에 있는지 확인한다.
REM      where python
REM      python --version
REM  - where python 이 C:\...\python.exe 경로를 출력하면 PATH 에 있는 것이고,
REM    python --version 이 "Python 3.x.x" 를 찍으면 정상이다.
REM  - 반대로 where 가 "찾을 수 없습니다", python 이
REM    "'python'은(는) 내부 또는 외부 명령... 이 아닙니다" 를 내면 PATH 에 없는 것이다.
REM  - PATH 에 없으면 아래 python 을 전체 경로(예: C:\Python314\python.exe)로 바꾼다.
REM    (현재 이 PC 는 where python -> C:\Python314\python.exe, Python 3.14.0 로 정상)
REM ----------------------------------------------------------------
echo [%date% %time%] 시작 >> "%LOG%"
python "%SCRIPT%" --project "%PROJECT%" >> "%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
echo [%date% %time%] 종료 (exit=%RC%) >> "%LOG%"

if not "%RC%"=="0" (
  echo [오류] 실행 실패. 로그 확인: "%LOG%"
  exit /b %RC%
)
echo [완료] 리포트 생성됨. analysis 폴더와 로그를 확인하세요: "%LOG%"
exit /b 0
