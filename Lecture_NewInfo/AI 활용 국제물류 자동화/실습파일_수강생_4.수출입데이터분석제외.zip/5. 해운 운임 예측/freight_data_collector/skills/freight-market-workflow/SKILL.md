---
name: freight-market-workflow
description: 해운·물류 시장자료를 "수집 → 병합 → 분석계산(context.json) → LLM 시황 서술 → HTML 리포트" 순으로 처리하는 워크플로우 스킬이다. freight-market-workflowbypython 과 달리 분석 문장을 규칙엔진이 아니라 LLM이 작성한다. 파이썬(build_context.py)이 SCFI·KCCI·WTI 변화율을 계산해 context.json 을 저장하면, LLM이 그 숫자를 읽고 시황 서술(narrative.json)을 쓰고, 파이썬(build_report.py)이 둘을 합쳐 HTML 리포트를 만든다. "운임 워크플로우", "freight market workflow", "LLM 시황 리포트" 등으로 호출한다.
---

# Freight Market Workflow (LLM 시황 서술)

SCFI 복합지수·KCCI 종합지수·EIA WTI 현물 자료를 자동으로 **수집 → 병합 →
분석계산 → LLM 시황 서술 → HTML 리포트** 순서로 처리하는 스킬이다.

## 기존 스킬과의 차이 (핵심)

자매 스킬 `freight-market-workflowbypython` 은 `rules.py` 가 변화율을 임계
규칙에 대입해 분석 문장을 결정론적으로 '찍어낸다'. 이 스킬은 다르다. **파이썬은
숫자만 계산**해 `context.json` 에 저장하고, **시황 서술 문장은 LLM 이 그 숫자를
읽고 직접 작성**한다. 따라서 정성 변수(지정학·공급망·정책)를 반영한 유연한
해석이 가능하다. 대신 같은 입력이라도 서술은 매번 달라질 수 있다.

| 단계 | 담당 | 산출물 |
|------|------|--------|
| 1. 수집→병합→분석계산 | 파이썬 `build_context.py` | `output/context.json` |
| 2. 시황 서술 작성 | **LLM** | `output/narrative.json` |
| 3. 리포트 생성 | 파이썬 `build_report.py` | `analysis/market_analysis_llm_*.html` |

## 실행 절차

이 스킬이 호출되면 다음 세 단계를 **순서대로** 수행한다.

### 1단계 — context.json 생성 (파이썬)

작업 폴더(`collect_*.py`, `merge_freight_data.py`, `output/` 가 있는
freight_data_collector)에서 아래를 실행한다.

```bash
python <스킬>/scripts/build_context.py --project "<freight_data_collector 폴더>"
```

- 처음 수집부터 새로 하려면 위와 같이 실행한다.
- 수집 없이 기존 CSV로 계산만 하려면 `--no-collect` 를 붙인다.
- 결과로 `output/context.json` 이 생성된다.

### 2단계 — narrative.json 작성 (LLM, 가장 중요한 단계)

`output/context.json` 을 읽는다. 이 파일에는 다음 숫자가 들어 있다.

- `scfi` / `wti` 블록: `last`(현재값), `last_date`, `wk_chg`·`wk_pct`(주간),
  `m_chg`·`m_pct`(1개월), `q_chg`·`q_pct`(3개월), `yr_high`·`yr_low`(1년 최고·최저),
  `from_high_pct`(고점 대비 %), `up_streak`(연속 상승 주수).
- `kcci` 블록: `last`, `last_date`, `wk_chg`, `wk_pct` (없으면 null).
- `kobc` 블록: `scfi_routes`(항로별 표), `kobc_meta`, `bdi` 등 (있을 때만).

이 숫자에 근거해 아래 7개 키를 가진 `output/narrative.json` 을 작성한다.
**모든 문장은 context.json 의 수치에만 근거한 사실 서술로 쓰고, `~다` 로 끝나는
일반체로 작성하며, 날짜는 YYYY-MM-DD 로 표기한다.** 숫자를 지어내지 않는다.

```json
{
  "sec1": "운임 시장의 현재 수준 — SCFI/KCCI/WTI 현재값과 1년 위치를 서술한다.",
  "sec2": "최근 3개월 방향성 — 3개월·1개월 변화율로 추세와 속도를 서술한다.",
  "sec3": "다음 분기 전망 — 모멘텀에 정성 변수를 더한 해석적 전망을 서술한다.",
  "sec4": "SCFI·KCCI 방향 비교 — 두 지수의 동조/괴리를 서술한다(KCCI 없으면 생략 사유).",
  "sec5": "WTI 유가의 비용·협상력 영향 — 유가 수준·방향이 연료비·협상력에 미치는 영향을 서술한다.",
  "summary": [
    ["현재", "한 줄 요약"],
    ["방향", "한 줄 요약"],
    ["전망", "한 줄 요약"],
    ["유의", "전망의 한계·전제 등 유의사항"]
  ]
}
```

각 `secN` 은 2~4문장 분량을 권장한다. `summary` 의 각 항목은 `[라벨, 문장]`
형태의 2원소 배열이다. 작성한 JSON 을 `output/narrative.json` 으로 저장한다.

### 3단계 — HTML 리포트 생성 (파이썬)

```bash
python <스킬>/scripts/build_report.py --project "<freight_data_collector 폴더>"
```

- `output/context.json`(숫자)과 `output/narrative.json`(서술)을 합쳐
  `analysis/market_analysis_llm_YYYYMMDD_HHMM.html` 한 파일을 만든다.
- 카드·표·차트 수치는 context.json 에서, 1~6절 문장은 narrative.json 에서 가져온다.
- narrative.json 의 어떤 절이 비어 있으면 해당 절에 보완 안내 문구가 들어가므로,
  비어 있던 절을 채워 2단계를 다시 한 뒤 3단계를 재실행하면 된다.

마지막으로 생성된 HTML 경로를 사용자에게 알리고 파일을 보여준다.

## 입력/출력 규약

- 입력: `output/freight_market_dataset.csv`(병합 결과, 1단계가 생성). KCCI 종합지수와
  SCFI 항로별 표는 `ctx_out.json` 이 있으면 그 권위값을 재사용한다.
- 중간물: `output/context.json`(숫자), `output/narrative.json`(LLM 서술).
- 출력: `analysis/market_analysis_llm_YYYYMMDD_HHMM.html`(한 파일). 타임스탬프는
  KST(Asia/Seoul, UTC+9) 기준이다.
- 모든 날짜는 `YYYY-MM-DD` 로 표기한다.

## 구성 파일

| 파일 | 내용 |
|------|------|
| `scripts/build_context.py` | 수집→병합→분석계산→context.json (LLM 미사용) |
| `scripts/build_report.py`  | context.json+narrative.json→HTML 리포트 |

## 비고

- 변화율 기준: 3개월 = 마지막 일자 기준 90일 전 이후 첫 관측치, 1개월 = 30일 전
  이후 첫 관측치, 주간 = 직전 관측치(SCFI 주간, WTI 일간 1스텝).
- 수집 단계가 네트워크 차단 등으로 실패해도 기존 `output/` CSV 로 계속 진행한다.
- 결정론적 규칙 문장이 필요하면 자매 스킬 `freight-market-workflowbypython` 을 쓴다.
