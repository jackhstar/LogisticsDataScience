# -*- coding: utf-8 -*-
"""해운·물류 시장 분석 워크플로우 1단계 — 컨텍스트 생성(Python).

수집(collection) → 병합(merge) → 분석계산(metrics) 을 수행하고 그 결과를
output/context.json 한 파일로 저장한다. 이 단계는 LLM 해석을 전혀 쓰지 않는다.
변화율·연속상승·고점대비 등 '숫자'만 계산해 둔다. 시황 서술 문장은 다음 단계에서
LLM 이 context.json 을 읽고 작성한다.

실행
    python build_context.py [--project DIR] [--no-collect]

  --project DIR : 수집 스크립트(collect_*.py)와 output/ 가 있는 프로젝트 폴더.
                  생략 시 ① FREIGHT_PROJECT_DIR 환경변수 ② 현재 작업폴더
                  ③ 기본 경로 순으로 자동 탐색한다.
  --no-collect  : 수집 단계를 건너뛰고 기존 output/ CSV로 병합·계산만 수행한다.

출력
  - output/freight_market_dataset.csv, output/data_quality_report.csv (병합)
  - output/context.json (분석계산 결과 = 다음 LLM 단계의 입력)
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from datetime import datetime, timedelta

import pandas as pd

COLLECTORS = [
    "collect_eia_wti.py",
    "collect_scfi_composite.py",
    "collect_kcci_composite.py",
    "collect_kobc_focus.py",
]
DEFAULT_PROJECT = r"C:\Users\82109\Desktop\logistics\claude\freight_data_collector"


# ---- 프로젝트 폴더 탐색 -------------------------------------------------------
def resolve_project(arg_dir):
    candidates = [
        arg_dir,
        os.environ.get("FREIGHT_PROJECT_DIR"),
        os.getcwd(),
        DEFAULT_PROJECT,
    ]
    for c in candidates:
        if c and os.path.exists(os.path.join(c, "merge_freight_data.py")):
            return os.path.abspath(c)
    for c in candidates:
        if c and os.path.isdir(os.path.join(c, "output")):
            return os.path.abspath(c)
    raise SystemExit("[중단] 프로젝트 폴더를 찾지 못했다. --project 로 지정하라.")


# ---- 1) 수집 ------------------------------------------------------------------
def run_collect(project):
    """수집 스크립트를 순차 실행한다(실패는 건너뛰고 기록)."""
    results = []
    print("\n[1/3] 수집(collection) 단계")
    for script in COLLECTORS:
        path = os.path.join(project, script)
        if not os.path.exists(path):
            print(f"  - {script:<28} 건너뜀(파일 없음)")
            results.append((script, "skip", "파일 없음"))
            continue
        try:
            r = subprocess.run(
                [sys.executable, path], cwd=project,
                capture_output=True, text=True, timeout=180,
            )
            ok = r.returncode == 0 and "[ERROR]" not in (r.stdout + r.stderr)
            status = "ok" if ok else "fail"
            tail = (r.stdout.strip().splitlines() or ["(출력 없음)"])[-1]
            print(f"  - {script:<28} {status} :: {tail[:80]}")
            results.append((script, status, tail[:120]))
        except Exception as e:  # noqa: BLE001
            print(f"  - {script:<28} error :: {type(e).__name__}")
            results.append((script, "error", f"{type(e).__name__}: {e}"))
    return results


# ---- 2) 병합 ------------------------------------------------------------------
def run_merge(project):
    print("\n[2/3] 병합(merge) 단계")
    merge_py = os.path.join(project, "merge_freight_data.py")
    if not os.path.exists(merge_py):
        print("  - merge_freight_data.py 없음 → 기존 freight_market_dataset.csv 사용")
        return
    r = subprocess.run([sys.executable, merge_py], cwd=project,
                       capture_output=True, text=True, timeout=120)
    for line in r.stdout.strip().splitlines():
        print(f"    {line}")
    if r.returncode != 0:
        print(f"  [경고] 병합 스크립트 비정상 종료(code={r.returncode})")


# ---- 변화율 계산 헬퍼 ---------------------------------------------------------
def _clean_series(df, datecol, valcol):
    s = df[[datecol, valcol]].copy()
    s[datecol] = pd.to_datetime(s[datecol], errors="coerce")
    s[valcol] = pd.to_numeric(s[valcol], errors="coerce")
    s = s.dropna().sort_values(datecol).reset_index(drop=True)
    return s, datecol, valcol


def _base_on_or_after(s, datecol, target_date):
    later = s[s[datecol] >= target_date]
    return later.iloc[0] if not later.empty else s.iloc[0]


def lag_change(s, datecol, valcol, days):
    """마지막 값 대비 'days일 전 기준' 변화량/변화율을 계산한다."""
    if len(s) < 2:
        return None, None, None, None
    last = s.iloc[-1]
    base = _base_on_or_after(s, datecol, last[datecol] - timedelta(days=days))
    chg = float(last[valcol]) - float(base[valcol])
    pct = chg / float(base[valcol]) * 100 if base[valcol] else None
    return round(chg, 2), (round(pct, 2) if pct is not None else None), \
        base[datecol].strftime("%Y-%m-%d"), float(base[valcol])


def weekly_change(s, valcol):
    """직전 행 대비 변화(주간/일간 1스텝)."""
    if len(s) < 2:
        return None, None
    last, prev = float(s.iloc[-1][valcol]), float(s.iloc[-2][valcol])
    chg = last - prev
    pct = chg / prev * 100 if prev else None
    return round(chg, 2), (round(pct, 2) if pct is not None else None)


def up_streak(s, valcol):
    """끝에서부터 연속 상승한 스텝 수."""
    n, vals = 0, s[valcol].tolist()
    for i in range(len(vals) - 1, 0, -1):
        if vals[i] > vals[i - 1]:
            n += 1
        else:
            break
    return n


# ---- 컨텍스트 구축 ------------------------------------------------------------
def build_context(project):
    """병합 CSV + (있으면) ctx_out.json 으로 분석 컨텍스트를 만든다."""
    out_dir = os.path.join(project, "output")
    ds_path = os.path.join(out_dir, "freight_market_dataset.csv")
    if not os.path.exists(ds_path):
        raise SystemExit(f"[중단] 병합 데이터셋이 없다: {ds_path}")
    df = pd.read_csv(ds_path)

    ss, sdc, svc = _clean_series(df, "date", "scfi_value")
    ws, wdc, wvc = _clean_series(df, "date", "wti_value")

    def block(s, dc, vc):
        q = lag_change(s, dc, vc, 90)
        m = lag_change(s, dc, vc, 30)
        wk_chg, wk_pct = weekly_change(s, vc)
        last = s.iloc[-1]
        return {
            "last": float(last[vc]),
            "last_date": last[dc].strftime("%Y-%m-%d"),
            "q_chg": q[0], "q_pct": q[1], "q_base_date": q[2],
            "m_chg": m[0], "m_pct": m[1], "m_base_date": m[2],
            "wk_chg": wk_chg, "wk_pct": wk_pct,
            "yr_high": round(float(s[vc].max()), 2),
            "yr_low": round(float(s[vc].min()), 2),
            "from_high_pct": round(float(last[vc]) / float(s[vc].max()) * 100, 2),
            "up_streak": up_streak(s, vc),
            "x": s[dc].dt.strftime("%Y-%m-%d").tolist(),
            "y": [round(float(v), 2) for v in s[vc].tolist()],
        }

    ctx = {
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "scfi": block(ss, sdc, svc),
        "wti": block(ws, wdc, wvc),
        "kcci": _kcci_context(project, df),
    }
    ctx["kobc"] = _kobc_enrichment(project)
    return ctx


def _read_csv_safe(path: str):
    """존재하고 비어있지 않은 CSV만 DataFrame 으로 반환한다(아니면 None)."""
    try:
        if os.path.exists(path):
            d = pd.read_csv(path)
            if not d.empty:
                return d
    except Exception:  # noqa: BLE001
        return None
    return None


def _kcci_prev_composite(project: str, cur_date: str):
    """현재 발행일 이전의 KCCI 종합지수(전주값)를 찾는다.
    우선순위: output/kcci_history.csv > output/context.json. 없으면 None.
    """
    hist = _read_csv_safe(os.path.join(project, "output", "kcci_history.csv"))
    if hist is not None and {"date", "composite"} <= set(hist.columns):
        prev = hist[hist["date"].astype(str) < str(cur_date)]
        if not prev.empty:
            prev = prev.sort_values("date")
            try:
                return float(prev.iloc[-1]["composite"])
            except (TypeError, ValueError):
                pass
    try:
        cj = os.path.join(project, "output", "context.json")
        if os.path.exists(cj):
            with open(cj, encoding="utf-8") as f:
                kd = (json.load(f) or {}).get("kcci") or {}
            if kd.get("last") is not None and str(kd.get("last_date", "")) < str(cur_date):
                return float(kd["last"])
    except Exception:  # noqa: BLE001
        pass
    return None


def _kcci_append_history(project: str, date_str: str, composite) -> None:
    """KCCI (발행일, 종합지수)를 누적 이력에 기록한다(같은 날짜는 갱신)."""
    if not date_str or composite is None:
        return
    path = os.path.join(project, "output", "kcci_history.csv")
    try:
        if os.path.exists(path):
            h = pd.read_csv(path)
        else:
            h = pd.DataFrame(columns=["date", "composite"])
        h = h[h["date"].astype(str) != str(date_str)]
        h = pd.concat([h, pd.DataFrame([{"date": date_str, "composite": float(composite)}])],
                      ignore_index=True)
        h = h.sort_values("date")
        h.to_csv(path, index=False)
    except Exception:  # noqa: BLE001
        pass


def _kcci_context(project: str, df: pd.DataFrame) -> dict:
    """KCCI 종합지수와 주간 변화.
    우선순위: 수집본(output/kcci_composite.csv) > ctx_out.json > 병합 CSV.
    수집본의 셀 순서가 바뀌어도(라벨 역전) 견고하도록 종합지수는 행 내 숫자 중
    '지수 범위(>=500)의 최댓값'으로 판정하고, 발행일을 그대로 사용한다. 주간
    변화는 직전 발행일의 종합지수(이력/context.json)와 비교해 계산한다. 이로써
    리포트가 별도 권위파일이 아니라 실제 수집 날짜·값을 자동 반영한다.
    """
    res = {"last": None, "last_date": "", "wk_chg": None, "wk_pct": None}

    # 1) 수집본 우선 — 수집 날짜·값이 자동 반영된다
    kc = _read_csv_safe(os.path.join(project, "output", "kcci_composite.csv"))
    if kc is not None:
        row = kc.iloc[-1]
        cand = []
        for col in ("index_value", "change_value"):
            if col in kc.columns and pd.notna(row.get(col)):
                try:
                    cand.append(float(row.get(col)))
                except (TypeError, ValueError):
                    pass
        idx_cands = [v for v in cand if abs(v) >= 500]
        comp = max(idx_cands) if idx_cands else (max(cand, key=abs) if cand else None)
        pubd = row.get("publish_date")
        date_str = str(pubd) if (pubd is not None and pd.notna(pubd)) else ""
        if comp is not None:
            res["last"] = float(comp)
            res["last_date"] = date_str
            prev = _kcci_prev_composite(project, date_str) if date_str else None
            if prev:
                res["wk_chg"] = round(float(comp) - prev, 2)
                res["wk_pct"] = round((float(comp) - prev) / prev * 100, 2)
            _kcci_append_history(project, date_str, float(comp))
            return res

    # 2) (레거시) ctx_out.json 권위값 — 수집본이 없을 때만 사용
    ctxj = _load_ctx_json(project)
    if ctxj and ctxj.get("kobc", {}).get("available"):
        kb = ctxj["kobc"]
        comp = kb.get("kcci_composite")
        prev = kb.get("kcci_prev")
        chg = kb.get("kcci_change")
        if comp is not None:
            res["last"] = float(comp)
            res["last_date"] = ctxj.get("kcci", {}).get("collected", {}).get("publish_date", "")
            if chg is not None and prev:
                res["wk_chg"] = float(chg)
                res["wk_pct"] = round(float(chg) / float(prev) * 100, 2)
            return res

    # 3) 병합 CSV 폴백(라벨 역전 가능 → 큰 값을 종합지수로 간주)
    if "kcci_index_value" in df.columns or "kcci_change_value" in df.columns:
        sub = df.dropna(subset=[c for c in ("kcci_index_value", "kcci_change_value")
                                if c in df.columns], how="all")
        if not sub.empty:
            row = sub.iloc[-1]
            vals = [row.get(c) for c in ("kcci_index_value", "kcci_change_value")
                    if c in df.columns and pd.notna(row.get(c))]
            if vals:
                res["last"] = float(max(vals))
                res["last_date"] = str(row.get("date", ""))
    return res


def _kobc_enrichment(project: str) -> dict:
    """KOBC 메타(제목·발행일)는 수집본(output/kobc_focus_meta.csv)을 우선 사용해
    수집 날짜가 자동 반영되도록 한다. 항로표·BDI 는 수집 단계에서 추출되지 않으므로
    ctx_out.json 이 있으면 재사용하고, 없으면 생략한다(리포트는 빈 표를 자동 생략).
    """
    out = {"scfi_routes": [], "kobc_meta": {}, "bdi": None, "bdi_prev": None}

    meta_csv = _read_csv_safe(os.path.join(project, "output", "kobc_focus_meta.csv"))
    if meta_csv is not None:
        r = meta_csv.iloc[-1]
        title = r.get("title")
        pubd = r.get("publish_date")
        out["kobc_meta"] = {
            "title": str(title) if pd.notna(title) else "",
            "publish_date": str(pubd) if pd.notna(pubd) else "",
        }

    ctxj = _load_ctx_json(project)
    if ctxj:
        kb = ctxj.get("kobc", {})
        out["scfi_routes"] = kb.get("scfi_routes", []) or []
        out["bdi"] = kb.get("bdi")
        out["bdi_prev"] = kb.get("bdi_prev")
        if not out["kobc_meta"]:
            out["kobc_meta"] = ctxj.get("kobc_meta", {})
    return out


def _load_ctx_json(project):
    p = os.path.join(project, "ctx_out.json")
    if os.path.exists(p):
        try:
            with open(p, encoding="utf-8") as f:
                return json.load(f)
        except Exception:  # noqa: BLE001
            return None
    return None


def write_context(project, ctx):
    out_dir = os.path.join(project, "output")
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, "context.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(ctx, f, ensure_ascii=False, indent=2)
    return path


# ---- main --------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", default=None)
    ap.add_argument("--no-collect", action="store_true")
    args = ap.parse_args()

    project = resolve_project(args.project)
    print(f"프로젝트 폴더: {project}")

    if args.no_collect:
        print("\n[1/3] 수집 단계 건너뜀(--no-collect)")
    else:
        run_collect(project)

    run_merge(project)

    print("\n[3/3] 분석계산 → context.json 단계")
    ctx = build_context(project)
    path = write_context(project, ctx)

    s, w = ctx["scfi"], ctx["wti"]
    print(f"  - SCFI {s['last']:,.2f}pt (주간 {s['wk_pct']}% / 3개월 {s['q_pct']}%)")
    print(f"  - WTI  {w['last']:,.2f}달러 (1개월 {w['m_pct']}% / 3개월 {w['q_pct']}%)")
    print(f"[완료] context.json 저장 -> {path}")
    print("[다음] 이 파일을 LLM이 읽고 시황 서술(narrative.json)을 작성한 뒤,")
    print("       build_report.py 로 HTML 리포트를 생성한다.")


if __name__ == "__main__":
    main()


# ====================================================================
# [캐시 말단 절단 방어용 패딩 — 삭제 금지]
# 스킬 등록(캐시) 시 파일 끝 일부 바이트가 잘려 SyntaxError 가 나는 현상
# 방어용. 핵심 코드(main 호출)가 파일 끝에 오지 않도록 여백을 둔다.
# padding 01 ------------------------------------------------
# padding 02 ------------------------------------------------
# padding 03 ------------------------------------------------
# padding 04 ------------------------------------------------
# padding 05 ------------------------------------------------
# padding 06 ------------------------------------------------
# padding 07 ------------------------------------------------
# padding 08 ------------------------------------------------
# padding 09 ------------------------------------------------
# padding 10 ------------------------------------------------
# padding 11 ------------------------------------------------
# padding 12 ------------------------------------------------
# padding 13 ------------------------------------------------
# padding 14 ------------------------------------------------
# padding 15 ------------------------------------------------
# padding 16 ------------------------------------------------
# padding 17 ------------------------------------------------
# padding 18 ------------------------------------------------
# padding 19 ------------------------------------------------
# padding 20 ------------------------------------------------
# padding 21 ------------------------------------------------
# padding 22 ------------------------------------------------
# padding 23 ------------------------------------------------
# padding 24 ------------------------------------------------
# padding 25 ------------------------------------------------
# padding 26 ------------------------------------------------
# padding 27 ------------------------------------------------
# padding 28 ------------------------------------------------
# padding 29 ------------------------------------------------
# padding 30 ------------------------------------------------
# ===================== end of padding ===============================
