# -*- coding: utf-8 -*-
"""해운·물류 시장 분석 워크플로우 3단계 — HTML 리포트 생성(Python).

build_context.py 가 만든 output/context.json(숫자) 과 LLM 이 작성한
output/narrative.json(시황 서술 문장) 을 합쳐 단일 HTML 리포트를 만든다.
이 단계는 숫자 포맷과 차트·표 렌더링만 담당하며, 분석 문장은 LLM 서술을 그대로 싣는다.

실행
    python build_report.py [--project DIR]
        [--context output/context.json] [--narrative output/narrative.json]

출력
  - analysis/market_analysis_llm_YYYYMMDD_HHMM.html (한 파일)

narrative.json 스키마(LLM 이 채운다)
  {
    "sec1": "운임 시장의 현재 수준 서술 …",
    "sec2": "최근 3개월 방향성 서술 …",
    "sec3": "다음 분기 전망 서술 …",
    "sec4": "SCFI·KCCI 방향 비교 서술 …",
    "sec5": "WTI 유가의 비용·협상력 영향 서술 …",
    "summary": [["현재","…"], ["방향","…"], ["전망","…"], ["유의","…"]]
  }
"""
from __future__ import annotations

import argparse
import json
import os
from datetime import datetime


# ---- 숫자 포맷 헬퍼 -----------------------------------------------------------
def fmt(v, nd=2):
    if v is None:
        return "N/A"
    try:
        f = float(v)
    except (TypeError, ValueError):
        return str(v)
    if nd == 0 or f == int(f):
        return f"{int(round(f)):,}"
    return f"{f:,.{nd}f}"


def signed(v, nd=2):
    if v is None:
        return "N/A"
    f = float(v)
    body = fmt(abs(f), nd)
    return f"+{body}" if f >= 0 else f"-{body}"


def arrow(pct):
    if pct is None:
        return "-"
    return "▲" if pct > 0 else ("▼" if pct < 0 else "-")


# ---- 입력 로드 ----------------------------------------------------------------
def resolve_project(arg_dir):
    for c in (arg_dir, os.environ.get("FREIGHT_PROJECT_DIR"), os.getcwd(),
              r"C:\Users\82109\Desktop\logistics\claude\freight_data_collector"):
        if c and os.path.isdir(os.path.join(c, "output")):
            return os.path.abspath(c)
    raise SystemExit("[중단] 프로젝트 폴더를 찾지 못했다. --project 로 지정하라.")


def load_json(path, what):
    if not os.path.exists(path):
        raise SystemExit(f"[중단] {what} 파일이 없다: {path}")
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def normalize_narrative(nar):
    """narrative.json 을 검사하고 누락 절은 안내 문구로 채운다."""
    miss = "(이 절의 서술이 narrative.json 에 비어 있다. LLM 서술 단계를 확인하라.)"
    out = {}
    for key in ("sec1", "sec2", "sec3", "sec4", "sec5"):
        v = nar.get(key)
        out[key] = v.strip() if isinstance(v, str) and v.strip() else miss
    summ = nar.get("summary") or []
    rows = []
    for item in summ:
        if isinstance(item, (list, tuple)) and len(item) >= 2:
            rows.append((str(item[0]), str(item[1])))
        elif isinstance(item, dict) and "label" in item and "text" in item:
            rows.append((str(item["label"]), str(item["text"])))
    out["summary"] = rows or [("요약", miss)]
    return out


# ---- HTML 조립 ----------------------------------------------------------------
def _card(title, value, pct, extra=""):
    cls = "up" if (pct or 0) > 0 else ("down" if (pct or 0) < 0 else "")
    sub = f"{arrow(pct)}{signed(pct,1) if pct is not None else ''}%"
    return (f"<div class='card'><div class='k'>{title}</div>"
            f"<div class='v'>{value}</div>"
            f"<div class='{cls}'>{sub}{(' · ' + extra) if extra else ''}</div></div>")


def _routes_table(routes):
    if not routes:
        return ""
    rows = ""
    for r in routes:
        cur, prev = r.get("cur"), r.get("prev")
        d = (cur or 0) - (prev or 0)
        cls = "up" if d > 0 else ("down" if d < 0 else "")
        rows += (f"<tr><td class='l'>{r.get('route','')}</td>"
                 f"<td>{fmt(cur,0)}</td><td>{fmt(prev,0)}</td>"
                 f"<td class='{cls}'>{arrow(d)}{fmt(abs(d),0)}</td></tr>")
    return ("<div class='panel'><h2>[부록] SCFI 주요 항로</h2>"
            "<table><tr><th>항로</th><th>금주</th><th>전주</th><th>증감</th></tr>"
            f"{rows}</table>"
            "<div class='note'>* 美서안·美동안: $/FEU, 그 외: $/TEU</div></div>")


def build_html(ctx, nar):
    s, w, k = ctx["scfi"], ctx["wti"], ctx.get("kcci") or {}
    kobc = ctx.get("kobc") or {}
    meta = kobc.get("kobc_meta", {})
    gen = ctx.get("generated_at", datetime.now().strftime("%Y-%m-%d %H:%M"))

    cards = _card(f"SCFI 복합 ({s['last_date']})", f"{fmt(s['last'])}", s["wk_pct"],
                  f"{s['up_streak']}주 연속↑" if s.get("up_streak", 0) >= 2 else "")
    if k.get("last") is not None:
        cards += _card(f"KCCI 종합 ({k.get('last_date','')})", f"{fmt(k['last'],0)}", k.get("wk_pct"))
    cards += _card(f"WTI 현물 ({w['last_date']})", f"${fmt(w['last'])}", w["m_pct"], "월간")

    def panel(num, title, body):
        return f"<div class='panel'><h2>{num}. {title}</h2><p>{body}</p></div>"

    summary = "".join(
        f"<div class='srow'><div class='slab'>- {lab}</div><div class='stxt'>{txt}</div></div>"
        for lab, txt in nar["summary"])

    meta_line = f" · {meta['title']}" if meta.get("title") else ""

    return f"""<!DOCTYPE html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>해운·물류 시장 분석(LLM 서술) {gen}</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
 body{{font-family:'Malgun Gothic','Apple SD Gothic Neo','Nanum Gothic',sans-serif;margin:0;background:#f4f6f8;color:#1c2b36}}
 .wrap{{max-width:1000px;margin:0 auto;padding:26px}}
 h1{{font-size:25px;margin:0 0 3px;color:#0b3d5c}} .sub{{color:#62707b;font-size:12.5px;margin-bottom:16px}}
 .hr{{height:2px;background:#0b3d5c;margin:0 0 16px}}
 .badge{{display:inline-block;background:#1d6fb8;color:#fff;font-size:11px;border-radius:4px;padding:2px 7px;margin-left:6px}}
 .cards{{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:18px}}
 .card{{flex:1;min-width:200px;background:#fff;border-radius:10px;padding:14px 16px;box-shadow:0 1px 3px rgba(0,0,0,.08)}}
 .card .k{{font-size:12px;color:#62707b}} .card .v{{font-size:26px;font-weight:700;color:#0b3d5c;margin:4px 0}}
 .up{{color:#c0392b}} .down{{color:#1d6fb8}}
 .panel{{background:#fff;border-radius:10px;padding:16px 20px;margin-bottom:14px;box-shadow:0 1px 3px rgba(0,0,0,.08)}}
 h2{{font-size:16px;color:#0b3d5c;margin:0 0 9px;border-left:4px solid #0b3d5c;padding-left:9px}}
 p{{line-height:1.72;font-size:14px;margin:0;white-space:pre-wrap}}
 .srow{{display:flex;gap:14px;padding:9px 0;border-bottom:1px solid #eef1f4}} .srow:last-child{{border-bottom:none}}
 .slab{{flex:0 0 70px;font-weight:700;color:#0b3d5c;font-size:14px}} .stxt{{flex:1;line-height:1.65;font-size:13.5px}}
 table{{width:100%;border-collapse:collapse;font-size:12.5px}}
 th,td{{border:1px solid #dde3e8;padding:5px 8px;text-align:center}} td.l{{text-align:left}}
 th{{background:#0b3d5c;color:#fff}} tr:nth-child(even) td{{background:#eef3f7}}
 .note{{font-size:11.5px;color:#7a8893;margin-top:10px}}
</style></head><body><div class="wrap">
<h1>해운·물류 시장 상황 분석<span class="badge">LLM 시황 서술</span></h1>
<div class="sub">생성일시 {gen} · 자료: SCFI 복합지수, KCCI 복합지수, EIA WTI 현물(최근 1년){meta_line}</div>
<div class="hr"></div>
<div class="cards">{cards}</div>
<div class="panel"><h2>SCFI 복합지수 · WTI 현물 추세 (최근 1년)</h2>
<div style="position:relative;height:320px"><canvas id="chart"></canvas></div></div>
{panel("1","운임 시장의 현재 수준", nar["sec1"])}
{panel("2","최근 3개월 방향성", nar["sec2"])}
{panel("3","다음 분기 전망", nar["sec3"])}
{panel("4","SCFI·KCCI 방향 비교", nar["sec4"])}
{panel("5","WTI 유가의 비용·협상력 영향", nar["sec5"])}
<div class="panel" style="border:2px solid #0b3d5c"><h2>6. 요약</h2>{summary}</div>
{_routes_table(kobc.get("scfi_routes"))}
<div class="note">※ 본 리포트의 카드·표·차트 수치는 수집·병합 데이터(context.json)에 근거하며,
1~6절의 분석 문장은 그 수치를 바탕으로 LLM 이 작성한 시황 서술(narrative.json)이다.
수치 근거는 SCFI 복합지수·KCCI 복합지수(KOBC)·EIA WTI 현물이다.</div>
</div>
<script>
const sx={json.dumps(s['x'])}, sy={json.dumps(s['y'])};
const wx={json.dumps(w['x'])}, wy={json.dumps(w['y'])};
(function(){{
 var el=document.getElementById('chart');
 if(typeof Chart==='undefined'){{el.insertAdjacentHTML('afterend','<div class=note>차트는 인터넷 연결 시 표시된다.</div>');return;}}
 var sM={{}}; sx.forEach((d,i)=>sM[d]=sy[i]);
 var wM={{}}; wx.forEach((d,i)=>wM[d]=wy[i]);
 var labels=Array.from(new Set(sx.concat(wx))).sort();
 new Chart(el,{{type:'line',data:{{labels:labels,datasets:[
  {{label:'SCFI 복합지수',data:labels.map(d=>d in sM?sM[d]:null),borderColor:'#c0392b',yAxisID:'y',pointRadius:0,borderWidth:2,tension:.25,spanGaps:true}},
  {{label:'WTI ($/bbl)',data:labels.map(d=>d in wM?wM[d]:null),borderColor:'#1d6fb8',yAxisID:'y1',pointRadius:0,borderWidth:2,tension:.25,spanGaps:true}}]}},
  options:{{responsive:true,maintainAspectRatio:false,interaction:{{mode:'index',intersect:false}},
   plugins:{{legend:{{position:'top'}}}},scales:{{x:{{ticks:{{maxTicksLimit:10,autoSkip:true}}}},
    y:{{position:'left',title:{{display:true,text:'SCFI'}}}},
    y1:{{position:'right',title:{{display:true,text:'WTI'}},grid:{{drawOnChartArea:false}}}}}}}}}});
}})();
</script></body></html>"""


def write_report(project, html):
    out_dir = os.path.join(project, "analysis")
    os.makedirs(out_dir, exist_ok=True)
    fname = f"market_analysis_llm_{datetime.now().strftime('%Y%m%d_%H%M')}.html"
    path = os.path.join(out_dir, fname)
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)
    return path


# ---- main --------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", default=None)
    ap.add_argument("--context", default=None)
    ap.add_argument("--narrative", default=None)
    args = ap.parse_args()

    project = resolve_project(args.project)
    ctx_path = args.context or os.path.join(project, "output", "context.json")
    nar_path = args.narrative or os.path.join(project, "output", "narrative.json")
    print(f"프로젝트 폴더: {project}")
    print(f"  - context  : {ctx_path}")
    print(f"  - narrative: {nar_path}")

    ctx = load_json(ctx_path, "context.json")
    nar = normalize_narrative(load_json(nar_path, "narrative.json"))
    html = build_html(ctx, nar)
    path = write_report(project, html)
    print(f"[완료] HTML 리포트 저장 -> {path}")


if __name__ == "__main__":
    main()


# ====================================================================
# [캐시 말단 절단 방어용 패딩 — 삭제 금지]
# 일부 환경에서 스킬 등록(캐시) 시 .py 파일 끝 수 바이트가 잘려
# SyntaxError 가 발생하는 현상이 있다. 핵심 코드가 파일 맨 끝에 오지
# 않도록 여백을 둔다. 캐시가 끝부분을 잘라도 잘리는 것은 이 주석뿐이다.
# padding 01 ------------------------------------------------
# padding 02 ------------------------------------------------
# padding 03 ------------------------------------------------
# padding 04 ------------------------------------------------
# padding 05 ------------------------------------------------
# padding 06 ------------------------------------------------
# padding 07 ------------------------------------------------
# padding 08 ------------------------------------------------
# padding 09 ------------------------------------------------
# padding 10 ------------------------------------------------
# padding 11 ------------------------------------------------
# padding 12 ------------------------------------------------
# padding 13 ------------------------------------------------
# padding 14 ------------------------------------------------
# padding 15 ------------------------------------------------
# padding 16 ------------------------------------------------
# padding 17 ------------------------------------------------
# padding 18 ------------------------------------------------
# padding 19 ------------------------------------------------
# padding 20 ------------------------------------------------
# ===================== end of padding ===============================
