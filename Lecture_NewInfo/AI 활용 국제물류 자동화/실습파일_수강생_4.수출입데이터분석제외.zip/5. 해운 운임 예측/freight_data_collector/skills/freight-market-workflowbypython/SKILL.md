---
name: freight-market-workflowbypython
description: >
  해운·물류 시장자료를 "수집 → 병합 → HTML 분석 리포트 생성" 순서로 한 번에
  처리하는 워크플로우 스킬이다. 기존 freight-market-workflow 와 달리 분석 문장을
  LLM이 쓰지 않고, run_market_workflowbypython.py 가 SCFI·KCCI·WTI 의 숫자 변화율을
  임계 규칙에 대입해 결정론적으로 '찍어낸다'. "운임 워크플로우 파이썬으로",
  "freight market workflow bypython", "규칙 기반 시장 리포트" 등으로 호출한다.
---

# Freight Market Workflow (Python 규칙 기반)

SCFI 종합지수·KCCI 종합지수·EIA WTI 현물 자료를 자동으로 **수집 → 병합 →
HTML 리포트 생성** 순서로 처리하는 스킬이다.

## 기존 스킬과의 차이 (핵심)

기존 `freight-market-workflow` 는 병합된 수치를 LLM이 해석해 분석 문장을
작성한다. 이 스킬은 **LLM 해석을 쓰지 않는다.** `scripts/rules.py` 가
변화율(%)을 임계 규칙에 대입해 문장을 결정론적으로 생성한다. 같은 입력이면
항상 같은 문장이 나온다. 따라서 빠르고 재현 가능하며, 토큰을 쓰지 않는다.

변화율 등급표(`rules.grade_pct`):

| 변화율(%) | 등급 |
|-----------|------|
| ≥ +10 | 급등 |
| +3 ~ +10 | 상승 |
| +1 ~ +3 | 소폭 상승 |
| -1 ~ +1 | 보합 |
| -3 ~ -1 | 소폭 하락 |
| -10 ~ -3 | 하락 |
| ≤ -10 | 급락 |

## 실행 절차

이 스킬이 호출되면 다음을 수행한다.

1. 작업 폴더(`collect_*.py`, `merge_freight_data.py`, `output/` 가 있는
   freight_data_collector)를 확인한다.
2. 아래 한 줄을 그 폴더에서 실행한다.

```bash
python /path/to/skills/freight-market-workflowbypython/scripts/run_market_workflowbypython.py --project "<freight_data_collector 폴더>"
```

   - 처음 수집부터 새로 하려면 위와 같이 실행한다(수집 → 병합 → 리포트).
   - 수집 없이 기존 CSV로 리포트만 빠르게 만들려면 `--no-collect` 를 붙인다.

3. 생성된 `analysis/market_analysis_bypython_YYYYMMDD_HHMM.html` 경로를
   사용자에게 알리고 파일을 보여준다.

## run_market_workflowbypython.py 가 하는 일

1. **수집(collection)** — `collect_eia_wti.py`, `collect_scfi_composite.py`,
   `collect_kcci_composite.py`, `collect_kobc_focus.py` 를 순차 실행한다.
   개별 실패는 건너뛰고 상태만 기록하므로 일부 자료원이 막혀도 멈추지 않는다.
   (`--no-collect` 시 생략)
2. **병합(merge)** — `merge_freight_data.py` 를 실행해
   `output/freight_market_dataset.csv`(SCFI·WTI·KCCI 시계열 outer-merge)와
   `output/data_quality_report.csv` 를 생성한다.
3. **분석·리포트(HTML)** — 병합 CSV에서 SCFI·WTI의 주간/1개월/3개월 변화율,
   1년 최고·최저, 연속 상승 주수를 계산하고, `rules.py` 로 7개 항목
   (현재 수준 / 3개월 방향성 / 다음 분기 전망 / SCFI·KCCI 비교 / WTI 영향 /
   요약)의 문장을 생성한 뒤, Chart.js 추세선과 카드·표를 포함한
   단일 HTML 파일로 저장한다.

## 입력/출력 규약

- 입력: `output/freight_market_dataset.csv` (병합 결과, 필수).
  KCCI 종합지수와 SCFI 항로별 표는 `ctx_out.json` 이 있으면 그 권위값을
  재사용하고, 없으면 해당 부분을 생략한 채 SCFI·WTI 중심으로 생성한다.
- 출력: `analysis/market_analysis_bypython_YYYYMMDD_HHMM.html` (한 파일).
- 모든 날짜는 `YYYY-MM-DD` 로 표기한다.

## 구성 파일

| 파일 | 내용 |
|------|------|
| `scripts/run_market_workflowbypython.py` | 수집→병합→리포트 오케스트레이터 |
| `scripts/rules.py` | 변화율 → 한국어 분석 문장 규칙 엔진 |

## 비고

- 변화율 기준: 3개월 = 마지막 일자 기준 90일 전 이후 첫 관측치, 1개월 = 30일
  전 이후 첫 관측치, 주간 = 직전 관측치(SCFI 주간, WTI 일간 1스텝).
- 본 스킬의 문장은 정성 변수(지정학·공급 정상화·정책)를 반영하지 않는다.
  정성 해석이 필요하면 기존 `freight-market-workflow` 스킬을 사용한다.
