# -*- coding: utf-8 -*-
"""
한국은행 ECOS 환율(USD/KRW)·국제 원유가(WTI) 20년 시계열 수집
- ECOS Open API(StatisticSearch)로 두 지표를 조회한다.
- 일별 원자료(RAW)와 월별 평균을 각각의 Sheet에 저장한다.
- 결과: raws/ecos_fx_wti.xlsx (4개 Sheet)
    환율 RAW / 월별 환율 / WTI RAW / 월별 WTI
- 인증키는 환경변수 ECOS_API_KEY 또는 작업 폴더 .env에서 읽는다.

WTI 통계표/항목 코드는 ECOS에서 바뀔 수 있어, 지정 코드가 비면
ECOS 메타데이터(StatisticTableList·StatisticItemList)에서 자동 탐색한다.
WTI가 일별이 아니면 제공 주기(월 등)로 자동 대체한다.

실행:  python collect_ecos_fx_wti.py
"""

import os
import sys
import datetime as dt
from pathlib import Path

import requests
import pandas as pd

# ──────────────────────────────────────────────────────────────────────────
# 코드 상단 변수 (URL · 통계코드 · 기간 · 출력)
# ──────────────────────────────────────────────────────────────────────────
ECOS_HOST = "https://ecos.bok.or.kr/api"
OUTPUT_DIR = "raws"
OUTPUT_FILE = "ecos_fx_wti.xlsx"
# 시작일은 고정한다("20년 전" 같은 상대 기간을 쓰지 않는다).
# 종료일은 실행일로 한다(재현성보다 최신 데이터 수집을 우선한다).
START_DATE = "2006-06-01"
PAGE_SIZE = 1000  # ECOS 1회 호출 최대 행 수

# 환율(USD/KRW) — 원/달러 환율(매매기준율), 일별
FX_STAT_CODE = "731Y001"
FX_CYCLE = "D"
FX_ITEM_CODE = "0000001"   # 원/미국달러(매매기준율)
FX_ROUTE_NAME = "USD/KRW"
FX_RAW_SHEET = "환율 RAW"
FX_MON_SHEET = "월별 환율"

# WTI 국제 원유가
# 코드를 알면 아래에 직접 지정한다. 비워두거나("") 조회 실패 시 자동 탐색한다.
WTI_STAT_CODE = ""       # 예: "902Y014" (자동 탐색이면 빈 값)
WTI_CYCLE = ""           # 예: "D" 또는 "M" (자동 탐색이면 빈 값)
WTI_ITEM_CODE = ""       # 자동 탐색이면 빈 값
WTI_ROUTE_NAME = "WTI"
WTI_RAW_SHEET = "WTI RAW"
WTI_MON_SHEET = "월별 WTI"

# 자동 탐색 키워드
WTI_TABLE_KEYWORDS = ["유가", "원유", "원자재", "국제상품", "상품가격", "석유"]
WTI_ITEM_KEYWORDS = ["WTI", "서부텍사스", "서부 텍사스"]
# WTI 항목이 전혀 없을 때 대체 후보(차선)
WTI_ITEM_FALLBACK = ["두바이", "Dubai", "브렌트", "Brent"]

SOURCE = "BOK ECOS"


# ──────────────────────────────────────────────────────────────────────────
# 인증키 / 기간
# ──────────────────────────────────────────────────────────────────────────
def load_api_key():
    key = os.environ.get("ECOS_API_KEY")
    if key:
        return key.strip()
    env_path = Path(__file__).resolve().parent / ".env"
    if env_path.exists():
        for line in env_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            if k.strip() == "ECOS_API_KEY":
                return v.strip().strip('"').strip("'")
    return None


def time_bounds(cycle):
    """주기에 맞는 검색 시작·종료 문자열을 반환한다(고정 기간 기반)."""
    start = dt.date.fromisoformat(START_DATE)
    end = dt.date.today()
    if cycle == "D":
        return start.strftime("%Y%m%d"), end.strftime("%Y%m%d")
    if cycle == "M":
        return start.strftime("%Y%m"), end.strftime("%Y%m")
    if cycle == "Q":
        return f"{start.year}Q1", f"{end.year}Q4"
    if cycle == "A":
        return str(start.year), str(end.year)
    return start.strftime("%Y%m%d"), end.strftime("%Y%m%d")


# ──────────────────────────────────────────────────────────────────────────
# ECOS 호출
# ──────────────────────────────────────────────────────────────────────────
def ecos_get(api_key, service, *parts):
    url = f"{ECOS_HOST}/{service}/{api_key}/json/kr/" + "/".join(str(p) for p in parts)
    resp = requests.get(url, timeout=30)
    resp.raise_for_status()
    return resp.json()


def statistic_search(api_key, stat_code, cycle, item_code):
    """StatisticSearch를 페이지 분할 호출해 row 리스트를 반환한다."""
    t_start, t_end = time_bounds(cycle)
    rows, page = [], 1
    while True:
        s = (page - 1) * PAGE_SIZE + 1
        e = page * PAGE_SIZE
        data = ecos_get(api_key, "StatisticSearch", s, e,
                        stat_code, cycle, t_start, t_end, item_code)
        if "RESULT" in data:
            code = data["RESULT"].get("CODE", "")
            msg = data["RESULT"].get("MESSAGE", "")
            if code == "INFO-200":  # 데이터 없음(끝)
                break
            raise RuntimeError(f"ECOS 오류 [{code}] {msg} (stat={stat_code})")
        block = data.get("StatisticSearch", {})
        page_rows = block.get("row", [])
        total = int(block.get("list_total_count", 0))
        rows.extend(page_rows)
        if len(rows) >= total or not page_rows:
            break
        page += 1
    return rows


def discover_wti(api_key):
    """ECOS 메타데이터에서 WTI 통계표·항목·주기를 자동 탐색한다."""
    # 1) 통계표 목록에서 유가/원유 관련 표 추출
    data = ecos_get(api_key, "StatisticTableList", 1, 10000)
    tables = data.get("StatisticTableList", {}).get("row", [])
    cand_tables = [
        t for t in tables
        if t.get("SRCH_YN") == "Y"
        and any(k in t.get("STAT_NAME", "") for k in WTI_TABLE_KEYWORDS)
    ]
    print(f"  유가 관련 통계표 후보 {len(cand_tables)}건")

    def scan(keywords):
        hits = []
        for t in cand_tables:
            stat_code = t.get("STAT_CODE", "")
            try:
                d = ecos_get(api_key, "StatisticItemList", 1, 10000, stat_code)
            except Exception:
                continue
            items = d.get("StatisticItemList", {}).get("row", []) or []
            for it in items:
                name = it.get("ITEM_NAME", "")
                if any(k.lower() in name.lower() for k in keywords):
                    hits.append({
                        "stat_code": stat_code,
                        "stat_name": t.get("STAT_NAME", ""),
                        "item_code": it.get("ITEM_CODE", ""),
                        "item_name": name,
                        "cycle": it.get("CYCLE", ""),
                        "start": it.get("START_TIME", ""),
                        "end": it.get("END_TIME", ""),
                    })
        return hits

    hits = scan(WTI_ITEM_KEYWORDS) or scan(WTI_ITEM_FALLBACK)
    if not hits:
        return None
    # 일별(D) 우선, 그다음 월별(M), 수록종료 최신순
    order = {"D": 0, "M": 1, "Q": 2, "A": 3}
    hits.sort(key=lambda h: (order.get(h["cycle"], 9), h["end"]), reverse=False)
    for h in hits[:8]:
        print(f"    - {h['stat_code']} [{h['cycle']}] {h['item_code']} "
              f"{h['item_name']} ({h['start']}~{h['end']}) / {h['stat_name']}")
    best = hits[0]
    print(f"  선택: {best['stat_code']} [{best['cycle']}] "
          f"{best['item_code']} {best['item_name']}")
    return best


# ──────────────────────────────────────────────────────────────────────────
# 변환
# ──────────────────────────────────────────────────────────────────────────
def parse_time(t):
    """ECOS TIME(YYYYMMDD/YYYYMM/YYYY)을 date로 변환한다."""
    if len(t) == 8:
        return dt.datetime.strptime(t, "%Y%m%d").date()
    if len(t) == 6:
        return dt.datetime.strptime(t + "01", "%Y%m%d").date()
    if len(t) == 4:
        return dt.date(int(t), 1, 1)
    return None


def rows_to_frames(rows):
    """ECOS row → (RAW DataFrame, 월별 평균 DataFrame)."""
    collected_at = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    recs = []
    for r in rows:
        t = r.get("TIME", "")
        v = r.get("DATA_VALUE", "")
        if not t or v in (None, "", "-"):
            continue
        try:
            value = float(v)
        except ValueError:
            continue
        d = parse_time(t)
        if d is None:
            continue
        recs.append({
            "date": d.strftime("%Y-%m-%d"),
            "value": value,
            "unit": r.get("UNIT_NAME", ""),
            "source": SOURCE,
            "collected_at": collected_at,
        })
    raw = pd.DataFrame(recs).sort_values("date").reset_index(drop=True)
    if raw.empty:
        return raw, raw
    tmp = raw.copy()
    tmp["month"] = tmp["date"].str.slice(0, 7)  # YYYY-MM
    unit = raw["unit"].iloc[0]
    monthly = tmp.groupby("month", as_index=False)["value"].mean().round(4)
    monthly["unit"] = unit
    monthly["source"] = SOURCE
    monthly["collected_at"] = collected_at
    monthly = monthly[["month", "value", "unit", "source", "collected_at"]]
    return raw, monthly


def report(name, raw, monthly):
    if raw.empty:
        print(f"[{name}] 수집 결과 없음")
        return
    print(f"[{name}] RAW {len(raw)}행 ({raw['date'].iloc[0]} ~ {raw['date'].iloc[-1]}), "
          f"월별 {len(monthly)}행")


# ──────────────────────────────────────────────────────────────────────────
# 메인
# ──────────────────────────────────────────────────────────────────────────
def main():
    api_key = load_api_key()
    if not api_key:
        print("오류: ECOS 인증키가 없다. 환경변수 ECOS_API_KEY 또는 .env에 설정한다.")
        sys.exit(1)

    print(f"수집 기간: {START_DATE} ~ {dt.date.today().isoformat()} (시작일 고정)")

    # 1) 환율
    try:
        fx_rows = statistic_search(api_key, FX_STAT_CODE, FX_CYCLE, FX_ITEM_CODE)
    except Exception as e:
        print(f"오류: 환율 수집 실패 - {e}")
        sys.exit(1)
    if not fx_rows:
        print("오류: 환율 데이터가 비어 있다. 통계/항목 코드를 확인한다.")
        sys.exit(1)
    fx_raw, fx_mon = rows_to_frames(fx_rows)
    report("환율 USD/KRW", fx_raw, fx_mon)

    # 2) WTI — 지정 코드 시도 후, 비면 자동 탐색
    wti_stat, wti_cycle, wti_item = WTI_STAT_CODE, WTI_CYCLE, WTI_ITEM_CODE
    wti_rows = []
    if wti_stat and wti_cycle and wti_item:
        try:
            wti_rows = statistic_search(api_key, wti_stat, wti_cycle, wti_item)
        except Exception as e:
            print(f"경고: 지정 WTI 코드 조회 실패({e}). 자동 탐색으로 전환한다.")
    if not wti_rows:
        print("WTI 자동 탐색 시작…")
        try:
            best = discover_wti(api_key)
        except Exception as e:
            print(f"오류: WTI 자동 탐색 실패 - {e}")
            sys.exit(1)
        if not best:
            print("오류: ECOS에서 WTI(또는 대체 유가) 항목을 찾지 못했다.")
            sys.exit(1)
        wti_stat, wti_cycle, wti_item = best["stat_code"], best["cycle"], best["item_code"]
        try:
            wti_rows = statistic_search(api_key, wti_stat, wti_cycle, wti_item)
        except Exception as e:
            print(f"오류: WTI 수집 실패 - {e}")
            sys.exit(1)
    if not wti_rows:
        print("오류: WTI 데이터가 비어 있다.")
        sys.exit(1)
    wti_raw, wti_mon = rows_to_frames(wti_rows)
    report(f"WTI({wti_stat}/{wti_cycle}/{wti_item})", wti_raw, wti_mon)

    # 3) 엑셀 저장
    out_dir = Path(__file__).resolve().parent / OUTPUT_DIR
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / OUTPUT_FILE
    with pd.ExcelWriter(out_path, engine="openpyxl") as xw:
        fx_raw.to_excel(xw, sheet_name=FX_RAW_SHEET, index=False)
        fx_mon.to_excel(xw, sheet_name=FX_MON_SHEET, index=False)
        wti_raw.to_excel(xw, sheet_name=WTI_RAW_SHEET, index=False)
        wti_mon.to_excel(xw, sheet_name=WTI_MON_SHEET, index=False)
    print(f"저장 완료: {out_path}")


if __name__ == "__main__":
    main()
