"""
SCFI 복합지수 월별 실적 수집 스크립트

forwarder.kr SCFI 페이지의 chartData에서 전체 이력(가장 긴 시계열)을 수집하여
raws/scfi_composite.xlsx 로 저장한다.
 - '주별 SCFI' 시트 : 주 단위 원자료
 - '월별 SCFI' 시트 : 주간 데이터를 월별로 집계한 자료 (month 컬럼 YYYY-MM)

기간 선택 원칙
 chartData는 기간별 키(예: '1month','3months','6months','1year','3years','5years')와
 전체 이력 블록으로 구성된다. 기간 키를 특정 값으로 단정하지 않는다.
 CHART_PERIOD_KEY 가 chartData의 실제 명시 키이면 그 구간을, 그렇지 않으면
 가장 긴 시계열(=전체 이력)을 자동 선택한다.

수집/파싱 실패 시 빈 파일을 만들지 않고 오류 메시지를 출력한 뒤 종료한다.
"""

import re
import sys
from pathlib import Path
from datetime import datetime

import requests
import pandas as pd

# ---------------------------------------------------------------------------
# 코드 상단 설정 변수
# ---------------------------------------------------------------------------
SCFI_PAGE_URL = "https://www.forwarder.kr/freight/index/scfi"
CHART_PERIOD_KEY = "full"            # 전체 이력 선택용 별칭. 명시 키가 아니면 최장 시계열 자동 선택
ROUTE_NAME = "SCFI Composite"
SOURCE_NAME = "Forwarder.kr SCFI Composite"
OUTPUT_DIR = Path("raws")
OUTPUT_FILE = OUTPUT_DIR / "scfi_composite.xlsx"

REQUEST_TIMEOUT = 20
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
)


# ---------------------------------------------------------------------------
# 1) HTML 수집
# ---------------------------------------------------------------------------
def fetch_html(url):
    """requests로 페이지 HTML을 가져온다."""
    resp = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=REQUEST_TIMEOUT)
    resp.raise_for_status()
    resp.encoding = resp.apparent_encoding or "utf-8"
    return resp.text


# ---------------------------------------------------------------------------
# 2) chartData 파싱 + 기간 선택
# ---------------------------------------------------------------------------
def parse_chart_data(html, period_key):
    """chartData 전체를 기간별 시계열로 파싱한 뒤 대상 구간을 선택한다.

    반환: (선택된 키, labels(날짜 리스트), data(지수값 리스트))
    - period_key 가 chartData의 실제 명시 키이면 그 구간을 사용
    - 그렇지 않으면 가장 긴 시계열(=전체 이력)을 자동 선택
    """
    pos = html.find("chartData")
    if pos == -1:
        raise ValueError("chartData를 찾지 못했습니다. (인라인 미존재 또는 구조 변경)")
    region = html[pos:]

    # "key": { labels:[...], data:[...] } 블록을 모두 추출
    blocks = re.findall(
        r"['\"]([^'\"]+)['\"]\s*:\s*\{\s*labels\s*:\s*\[(.*?)\]\s*,?\s*data\s*:\s*\[(.*?)\]",
        region,
        re.DOTALL,
    )
    if not blocks:
        raise ValueError("chartData 내부 블록(labels/data)을 파싱하지 못했습니다.")

    series = {}
    for key, labels_raw, data_raw in blocks:
        labels = [s.strip().strip("\"'") for s in labels_raw.split(",") if s.strip()]
        data = []
        for tok in data_raw.split(","):
            tok = tok.strip().strip("\"'")
            if tok:
                data.append(None if tok in ("null", "None") else float(tok))
        m = min(len(labels), len(data))
        if m:
            series[key] = (labels[:m], data[:m])

    if not series:
        raise ValueError("유효한 시계열을 찾지 못했습니다.")

    # 명시 키이면 해당 구간, 아니면 최장 시계열 자동 선택
    if period_key in series:
        chosen = period_key
    else:
        chosen = max(series, key=lambda k: len(series[k][0]))

    labels, data = series[chosen]
    return chosen, labels, data


# ---------------------------------------------------------------------------
# 3) 데이터프레임 구성
# ---------------------------------------------------------------------------
def build_weekly_df(labels, data, collected_at):
    df = pd.DataFrame({"date": labels, "scfi_value": data})
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df = df.dropna(subset=["date"]).sort_values("date").reset_index(drop=True)
    df["route"] = ROUTE_NAME
    df["source"] = SOURCE_NAME
    df["collected_at"] = collected_at
    return df[["date", "route", "scfi_value", "source", "collected_at"]]


def build_monthly_df(weekly_df, collected_at):
    """주간 데이터를 월평균으로 집계한다. month 컬럼은 YYYY-MM 문자열."""
    monthly = (
        weekly_df.set_index("date")["scfi_value"]
        .resample("ME")
        .mean()
        .round(2)
        .dropna()
        .reset_index()
    )
    monthly["month"] = monthly["date"].dt.strftime("%Y-%m")
    monthly["route"] = ROUTE_NAME
    monthly["source"] = SOURCE_NAME
    monthly["collected_at"] = collected_at
    return monthly[["month", "route", "scfi_value", "source", "collected_at"]]


# ---------------------------------------------------------------------------
# 4) 메인
# ---------------------------------------------------------------------------
def main():
    collected_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        html = fetch_html(SCFI_PAGE_URL)
        chosen_key, labels, data = parse_chart_data(html, CHART_PERIOD_KEY)
        weekly = build_weekly_df(labels, data, collected_at)
        monthly = build_monthly_df(weekly, collected_at)
        if weekly.empty:
            raise ValueError("유효한 날짜를 가진 주간 데이터가 없습니다.")
    except Exception as e:
        # 빈 파일을 만들지 않고 오류만 출력
        print(f"[오류] SCFI 데이터 수집 실패: {e}", file=sys.stderr)
        sys.exit(1)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(OUTPUT_FILE, engine="openpyxl") as writer:
        weekly.to_excel(writer, sheet_name="주별 SCFI", index=False)
        monthly.to_excel(writer, sheet_name="월별 SCFI", index=False)

    start = weekly["date"].min().date()
    end = weekly["date"].max().date()
    span_years = (weekly["date"].max() - weekly["date"].min()).days / 365.25
    note = "" if chosen_key == CHART_PERIOD_KEY else " (명시 키가 아니므로 최장 시계열 자동 선택)"
    print(f"[완료] {OUTPUT_FILE} 저장")
    print(f" - 선택 구간 : '{chosen_key}'{note}")
    print(f" - 확보 기간 : {start} ~ {end} (약 {span_years:.1f}년)")
    print(f" - 주별 SCFI : {len(weekly)} rows")
    print(f" - 월별 SCFI : {len(monthly)} rows")


if __name__ == "__main__":
    main()
