"""
forwarder.kr SCFI 페이지 구조 진단 스크립트

collect_scfi_composite.py 를 실제로 돌리기 전에, 페이지의 chartData 구조를
먼저 확인하기 위한 도구다. 다음을 출력한다.
 - chartData가 인라인 HTML에 존재하는지
 - 기간 키 이름이 무엇인지 (예: '1month','3months',... 그리고 전체 이력 키)
 - 각 labels 배열이 몇 개씩 들어있는지 (= 전체 이력이 인라인에 있는지 판단)

이 출력만 있으면 collect 스크립트의 CHART_PERIOD_KEY/파싱부를 정확히 맞출 수 있다.
"""

import re
import requests

SCFI_PAGE_URL = "https://www.forwarder.kr/freight/index/scfi"
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
)

resp = requests.get(SCFI_PAGE_URL, headers={"User-Agent": USER_AGENT}, timeout=20)
resp.raise_for_status()
resp.encoding = resp.apparent_encoding or "utf-8"
html = resp.text

print("=" * 70)
print(f"HTML 길이: {len(html):,} chars")
print(f"'chartData' 등장 횟수: {html.count('chartData')}")
print(f"'labels' 등장 횟수    : {html.count('labels')}")
print(f"'data' 등장 횟수      : {html.count('data')}")
print("=" * 70)

# 1) chartData 주변 원문 미리보기
idx = html.find("chartData")
if idx != -1:
    start = max(0, idx - 40)
    print("\n[chartData 주변 원문 800자]\n")
    print(html[start:start + 800])
else:
    print("\n[!] 'chartData'가 인라인 HTML에 없음 → AJAX/다운로드로 로드될 가능성")
    print("\n[script src 목록]")
    for m in re.findall(r'<script[^>]+src=["\']([^"\']+)["\']', html):
        print("  ", m)
    print("\n[.json / ajax / freight 관련 URL 힌트]")
    for m in set(re.findall(r'["\']([^"\']*(?:json|ajax|freight|chart|index)[^"\']*)["\']', html, re.I)):
        if len(m) < 120:
            print("  ", m)

# 2) 모든 labels 배열의 길이와 시작/끝 값
print("\n" + "=" * 70)
print("[발견된 labels 배열들 — 길이와 첫/끝 값]\n")
for i, m in enumerate(re.finditer(r"\blabels\b[\"']?\s*:\s*\[(.*?)\]", html, re.DOTALL)):
    items = [s.strip().strip("\"'") for s in m.group(1).split(",") if s.strip()]
    if items:
        print(f"  labels#{i}: {len(items)}개  | 처음={items[0]}  끝={items[-1]}")

# 3) chartData 인근 키 후보 추출
print("\n" + "=" * 70)
print("[chartData 인근 키 후보 (예: \"3months\": { ... })]\n")
if idx != -1:
    region = html[idx:idx + 8000]
    keys = re.findall(r'["\']([A-Za-z0-9_가-힣]+)["\']\s*:\s*\{', region)
    print("  ", keys if keys else "(객체형 키를 못 찾음 → 단일 배열 구조일 수 있음)")
