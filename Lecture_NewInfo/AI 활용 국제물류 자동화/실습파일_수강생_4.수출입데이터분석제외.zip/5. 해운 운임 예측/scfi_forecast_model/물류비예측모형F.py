# -*- coding: utf-8 -*-
"""
월별 물류비 예측 모형 개발 (최종판 F)
- 종속변수: 물류비(cost)
- 독립변수: 1/2/3개월전 물류비(lag_cost), 1/2/3개월전 SCFI(lag_scfi), 물동량, 월(원핫)
- 모형: 다중회귀(LinearRegression), 라쏘(LassoCV), 의사결정나무(DecisionTreeRegressor)
- 평가용 모형: 훈련(2016-04~2025-08) 적합 → 테스트(2025-09~2026-05) 평가
- 최종 모형  : 훈련+테스트 전체로 재적합 → 미래(2026-06~2026-12) 예측
- 입력: 실행 위치 하위 raws / 산출물: outputs/analysis
"""

import os
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

from sklearn.linear_model import LinearRegression, LassoCV
from sklearn.tree import DecisionTreeRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import mean_squared_error, r2_score


# ----------------------------------------------------------------------
# 0. 한글 폰트
# ----------------------------------------------------------------------
def set_korean_font():
    for cand in ["NanumGothic", "Malgun Gothic", "AppleGothic", "Noto Sans CJK KR"]:
        try:
            fm.findfont(cand, fallback_to_default=False)
            plt.rcParams["font.family"] = cand
            break
        except Exception:
            continue
    else:
        path = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
        try:
            fm.fontManager.addfont(path)
            plt.rcParams["font.family"] = fm.FontProperties(fname=path).get_name()
        except Exception:
            pass
    plt.rcParams["axes.unicode_minus"] = False

set_korean_font()

RAWS = "raws"
OUTPUT = os.path.join("outputs", "analysis")
os.makedirs(OUTPUT, exist_ok=True)

TRAIN_END = "2025-08"
TEST_START, TEST_END = "2025-09", "2026-05"
FUT_START, FUT_END = "2026-06", "2026-12"

MONTH_ALL = [f"month_{i}" for i in range(1, 13)]
MONTH_LINEAR = [f"month_{i}" for i in range(2, 13)]   # 더미 함정 방지(month_1 제외)


# ----------------------------------------------------------------------
# 1. 데이터 로드 & 월 키 통일
# ----------------------------------------------------------------------
def to_month_str(s):
    s = pd.to_datetime(s.astype(str), errors="coerce")
    return s.dt.strftime("%Y-%m")


def load_data():
    f_act = f"{RAWS}/customer_actuals_10yr.xlsx"
    f_scfi = f"{RAWS}/scfi_composite.xlsx"
    f_scfi_fc = f"{RAWS}/scfi_forecast_raw.xlsx"

    cost = pd.read_excel(f_act, sheet_name="월별 물류비").rename(columns={"value": "cost"})
    vol = pd.read_excel(f_act, sheet_name="월별 물동량").rename(columns={"value": "volume"})
    vol_fc = pd.read_excel(f_act, sheet_name="월별 물동량 전망").rename(columns={"value": "volume"})
    scfi = pd.read_excel(f_scfi, sheet_name="월별 SCFI")
    scfi = scfi[scfi["route"] == "SCFI Composite"][["month", "scfi_value"]].rename(
        columns={"scfi_value": "scfi"})
    scfi_fc = pd.read_excel(f_scfi_fc, sheet_name="월별 SCFI 전망").rename(
        columns={"Forecast_SCFi_Approx": "scfi"})

    for df in (cost, vol, vol_fc, scfi, scfi_fc):
        df["month"] = to_month_str(df["month"])

    volume = pd.concat([vol[["month", "volume"]], vol_fc[["month", "volume"]]], ignore_index=True)
    scfi_all = pd.concat([scfi[["month", "scfi"]], scfi_fc[["month", "scfi"]]], ignore_index=True)
    return cost[["month", "cost"]], volume, scfi_all


# ----------------------------------------------------------------------
# 2. 통합 테이블 (물류비 시차 + SCFI 시차 + 원핫 + split)
# ----------------------------------------------------------------------
def build_table(cost, volume, scfi_all):
    months = pd.period_range("2016-01", "2026-12", freq="M").strftime("%Y-%m")
    df = pd.DataFrame({"month": months})
    df = (df.merge(cost, on="month", how="left")
            .merge(scfi_all, on="month", how="left")
            .merge(volume, on="month", how="left"))
    df = df.sort_values("month").reset_index(drop=True)

    # 물류비 시차(실측 2016-01부터 → df 내부 shift)
    for k in (1, 2, 3):
        df[f"lag_cost_{k}"] = df["cost"].shift(k)
    # SCFI 시차(2014년 이후 실측 활용 위해 전체 계열에서 월 오프셋 매핑)
    s = scfi_all.drop_duplicates("month").set_index("month")["scfi"]
    for k in (1, 2, 3):
        df[f"lag_scfi_{k}"] = df["month"].map(
            lambda mn, k=k: s.get((pd.Period(mn, "M") - k).strftime("%Y-%m"), np.nan))

    m = pd.to_datetime(df["month"]).dt.month
    for i in range(1, 13):
        df[f"month_{i}"] = (m == i).astype(int)

    def label(mn):
        if mn <= TRAIN_END:
            return "train"
        if TEST_START <= mn <= TEST_END:
            return "test"
        if FUT_START <= mn <= FUT_END:
            return "future"
        return "drop"
    df["split"] = df["month"].map(label)
    return df


# ----------------------------------------------------------------------
# 3. 모형
# ----------------------------------------------------------------------
BASE = ["lag_cost_1", "lag_cost_2", "lag_cost_3",
        "lag_scfi_1", "lag_scfi_2", "lag_scfi_3", "volume"]
FEATURES_LINEAR = BASE + MONTH_LINEAR
FEATURES_TREE = BASE + MONTH_ALL


def build_models():
    return {
        "다중회귀": (LinearRegression(), FEATURES_LINEAR),
        "라쏘": (make_pipeline(StandardScaler(),
                              LassoCV(cv=5, max_iter=100000, random_state=0)), FEATURES_LINEAR),
        "의사결정나무": (DecisionTreeRegressor(max_depth=4, min_samples_leaf=5, random_state=0),
                     FEATURES_TREE),
    }


def fit_models(data):
    return {n: (est.fit(data[f].values, data["cost"].values), f)
            for n, (est, f) in build_models().items()}


def predict(model_feat, rows):
    model, feats = model_feat
    return model.predict(rows[feats].values)


def recursive_future(df, model_feat):
    """미래 구간을 한 달씩 예측하며 물류비 시차로 되먹임."""
    work = df.copy()
    cost = work.set_index("month")["cost"].copy()
    fut = work.loc[work["split"] == "future", "month"].tolist()
    preds = {}
    for mn in fut:
        i = work.index[work["month"] == mn][0]
        for k in (1, 2, 3):
            prev = (pd.Period(mn, "M") - k).strftime("%Y-%m")
            work.loc[i, f"lag_cost_{k}"] = cost.get(prev, np.nan)
        yhat = predict(model_feat, work.loc[[i]])[0]
        preds[mn] = yhat
        cost[mn] = yhat
    return preds


def rmse(y, yh):
    return float(np.sqrt(mean_squared_error(y, yh)))


# ----------------------------------------------------------------------
# 메인
# ----------------------------------------------------------------------
def main():
    cost, volume, scfi_all = load_data()
    df = build_table(cost, volume, scfi_all)

    valid_tt = df[BASE].notna().all(axis=1) & df["cost"].notna()
    train = df[(df["split"] == "train") & valid_tt].copy()
    test = df[(df["split"] == "test") & valid_tt].copy()
    future = df[df["split"] == "future"].copy()
    full = pd.concat([train, test], ignore_index=True)
    fut_months = future["month"].tolist()
    algos = ["다중회귀", "라쏘", "의사결정나무"]

    print("[INFO] 종속변수: 물류비(cost)")
    print("[INFO] 독립변수: 1/2/3개월전 물류비, 1/2/3개월전 SCFI, 물동량, 월(원핫)")
    print(f"[INFO] 훈련 시작 자동 조정: 지정 2015-01 → 실제 {train['month'].min()} "
          f"(물류비 실적 2016-01부터 + 3개월 시차)")
    print(f"[INFO] 훈련 {train['month'].min()}~{train['month'].max()} ({len(train)}) / "
          f"테스트 {test['month'].min()}~{test['month'].max()} ({len(test)}) / "
          f"미래 {future['month'].min()}~{future['month'].max()} ({len(future)})")

    # (A) 평가용: 훈련 적합 → 테스트 평가
    em = fit_models(train)
    pred_train = {n: predict(mf, train) for n, mf in em.items()}
    pred_test = {n: predict(mf, test) for n, mf in em.items()}

    rows = []
    for n in algos:
        rows.append({"모형": n,
                     "훈련 RMSE": rmse(train["cost"], pred_train[n]),
                     "훈련 R²": r2_score(train["cost"], pred_train[n]),
                     "테스트 RMSE": rmse(test["cost"], pred_test[n]),
                     "테스트 R²": r2_score(test["cost"], pred_test[n])})
    metrics = pd.DataFrame(rows)
    best = metrics.loc[metrics["테스트 RMSE"].idxmin(), "모형"]

    print("\n===== 모형별 성능 (RMSE 단위: 원) =====")
    show = metrics.copy()
    for c in ["훈련 RMSE", "테스트 RMSE"]:
        show[c] = show[c].map(lambda v: f"{v:,.0f}")
    for c in ["훈련 R²", "테스트 R²"]:
        show[c] = show[c].map(lambda v: f"{v:.4f}")
    print(show.to_string(index=False))
    print(f"[INFO] 테스트 RMSE 최저(추천 최종모델): {best}")

    # (B) 최종: 훈련+테스트 적합 → 미래 예측
    fm_ = fit_models(full)
    final_full = {n: predict(mf, full) for n, mf in fm_.items()}     # 적합값(시각화용)
    final_future = {n: np.array([recursive_future(df, mf)[m] for m in fut_months])
                    for n, mf in fm_.items()}
    # 검증(평가용) 모형의 미래 예측(모델별 시트용)
    eval_future = {n: np.array([recursive_future(df, mf)[m] for m in fut_months])
                   for n, mf in em.items()}

    # 모델별 월별(실적/예측) 프레임 헬퍼
    months_all = list(train["month"]) + list(test["month"]) + list(fut_months)
    actual_all = list(train["cost"]) + list(test["cost"]) + [np.nan] * len(fut_months)
    split_all = ["train"] * len(train) + ["test"] * len(test) + ["future"] * len(fut_months)

    def per_model_frame(p_tr, p_te, p_fu):
        pred = np.concatenate([np.asarray(p_tr), np.asarray(p_te), np.asarray(p_fu)])
        return pd.DataFrame({"month": months_all, "실적": actual_all,
                             "예측": np.round(pred), "구분": split_all})

    fut_tbl = pd.DataFrame({"month": fut_months})
    for n in algos:
        fut_tbl[n] = final_future[n]
    fut_tbl["추천_예측"] = final_future[best]

    print("\n===== 최종모델(훈련+테스트 적합) 미래 예측 2026-06~12 (단위: 원) =====")
    print(fut_tbl.assign(**{c: fut_tbl[c].map(lambda v: f"{v:,.0f}")
                            for c in fut_tbl.columns if c != "month"}).to_string(index=False))

    # ------------------------------------------------------------------
    # 통합 입력 테이블
    # ------------------------------------------------------------------
    out_cols = (["month", "cost", "lag_cost_1", "lag_cost_2", "lag_cost_3",
                 "scfi", "lag_scfi_1", "lag_scfi_2", "lag_scfi_3", "volume"]
                + MONTH_ALL + ["split"])
    table = df[df["split"] != "drop"][out_cols].copy()
    xlsx_path = f"{OUTPUT}/model_input_table.xlsx"
    table.to_excel(xlsx_path, index=False, sheet_name="model_input")
    _style_header(xlsx_path, "model_input")
    print(f"\n[저장] 통합 입력 테이블 → {xlsx_path} (행 {len(table)}, 열 {len(out_cols)})")

    res_path = f"{OUTPUT}/model_results.xlsx"
    with pd.ExcelWriter(res_path, engine="openpyxl") as w:
        metrics.to_excel(w, index=False, sheet_name="성능")
        for n in algos:   # 검증(평가용) 모형의 월별 실적/예측
            per_model_frame(pred_train[n], pred_test[n], eval_future[n]).to_excel(
                w, index=False, sheet_name=n)
    _style_sheets(res_path, ["성능"] + algos)
    print(f"[저장] 성능 테이블(+모델별 시트) → {res_path}")

    final_path = f"{OUTPUT}/final_model_result.xlsx"
    n_tr = len(train)
    with pd.ExcelWriter(final_path, engine="openpyxl") as w:
        fut_tbl.to_excel(w, index=False, sheet_name="최종예측")
        pd.DataFrame({"항목": ["추천 최종모델(테스트 RMSE 최저)", "적합 데이터"],
                      "값": [best, f"훈련+테스트 {full['month'].min()}~{full['month'].max()}"]}
                     ).to_excel(w, index=False, sheet_name="요약")
        for n in algos:   # 최종 모형의 월별 실적/예측
            per_model_frame(final_full[n][:n_tr], final_full[n][n_tr:], final_future[n]).to_excel(
                w, index=False, sheet_name=n)
    _style_sheets(final_path, ["최종예측", "요약"] + algos)
    print(f"[저장] 최종모델 미래예측(+모델별 시트) → {final_path}")

    # ------------------------------------------------------------------
    # 시각화 (검증 그래프 + 최종 그래프, 동일 형식: 3 알고리즘 서브플롯)
    #   실적=검정 / 훈련구간=파랑 / 테스트구간=빨강 / 미래=초록 점선
    # ------------------------------------------------------------------
    x_actual = pd.to_datetime(df.loc[df["cost"].notna(), "month"])
    y_actual = df.loc[df["cost"].notna(), "cost"]
    x_train = pd.to_datetime(train["month"]); x_test = pd.to_datetime(test["month"])
    x_full = pd.to_datetime(full["month"]); x_fut = pd.to_datetime(fut_months)
    bd, fbd = pd.to_datetime(TEST_START), pd.to_datetime(FUT_START)
    full_is_test = (full["month"] >= TEST_START).values

    def draw(kind):
        fig, axes = plt.subplots(3, 1, figsize=(13, 12), sharex=True)
        for ax, n in zip(axes, algos):
            ax.plot(x_actual, y_actual / 1e8, color="black", lw=1.6, label="실적")
            if kind == "eval":
                ax.plot(x_train, pred_train[n] / 1e8, color="blue", lw=1.4, label="훈련 예측")
                ax.plot(x_test, pred_test[n] / 1e8, color="red", lw=1.8, marker="o", ms=3, label="테스트 예측")
                r = metrics.loc[metrics["모형"] == n].iloc[0]
                sub = f"테스트 RMSE={r['테스트 RMSE']/1e8:.3f}억, R²={r['테스트 R²']:.3f}"
            else:
                yf = final_full[n]
                ax.plot(x_full[~full_is_test], yf[~full_is_test] / 1e8, color="blue", lw=1.4, label="훈련구간 적합")
                ax.plot(x_full[full_is_test], yf[full_is_test] / 1e8, color="red", lw=1.8,
                        marker="o", ms=3, label="테스트구간 적합")
                sub = "훈련+테스트 적합"
            ax.plot(x_fut, final_future[n] / 1e8, color="green", lw=1.8, ls="--",
                    marker="s", ms=3, label="미래 예측")
            ax.axvline(bd, color="gray", ls=":", lw=1); ax.axvline(fbd, color="gray", ls=":", lw=1)
            star = " ★추천" if n == best else ""
            ax.set_title(f"{n}{star}  ({sub})")
            ax.set_ylabel("물류비 (억원)")
            ax.legend(loc="upper left", fontsize=9, ncol=4)
            ax.grid(alpha=0.3)
        axes[-1].set_xlabel("월")
        ttl = ("[검증] 평가용 모형(훈련 적합) — 실적/훈련/테스트/미래"
               if kind == "eval" else
               "[최종] 최종 모형(훈련+테스트 적합) — 실적/적합/미래")
        fig.suptitle(ttl, fontsize=14, y=0.995)
        fig.tight_layout()
        path = f"{OUTPUT}/{'forecast_plot' if kind == 'eval' else 'final_model_plot'}.png"
        fig.savefig(path, dpi=130, bbox_inches="tight"); plt.close(fig)
        return path

    print(f"[저장] 검증 그래프 → {draw('eval')}")
    print(f"[저장] 최종모델 그래프 → {draw('final')}")


def _style_header(path, sheet):
    _style_sheets(path, [sheet])


def _style_sheets(path, sheets):
    from openpyxl import load_workbook
    from openpyxl.styles import Font, Alignment, PatternFill
    wb = load_workbook(path)
    fill = PatternFill("solid", fgColor="DDE7F0")
    for sheet in sheets:
        ws = wb[sheet]
        for cell in ws[1]:
            cell.font = Font(name="Arial", bold=True); cell.fill = fill
            cell.alignment = Alignment(horizontal="center")
        for col in ws.iter_cols(min_row=2):
            for cell in col:
                cell.font = Font(name="Arial")
        ws.freeze_panes = "B2"
    wb.save(path)


if __name__ == "__main__":
    main()
