# 대시보드 생성 — build_dashboard.py 안내

- 작성일: 2026-07-01
- 대상: 프로젝트 "[국제물류] 물류비 대시보드 (실습용)"
- 형태: S18 동적 대시보드(S18_dynamic_dashboard) 반영

> **분석은 대시보드 전에 끝낸다.** 모델 재학습·진단 계산은 상류(별도 스크립트·`make_diagnostics.py`)에서 마치고,
> `build_dashboard.py` 는 그 산출물을 읽어 대시보드용 값으로 조립하고 화면을 만든다. 매달 엑셀만 바꾼 뒤 이 파일 하나만 실행하면 대시보드가 최신화된다.

---

## 무엇을 하나

`build_dashboard.py` 는 `raws\` 와 `outputs\analysis\` 의 엑셀 실값만 읽어, S18 형태의 대시보드 데이터(`DASHBOARD_DATA`)를 조립한 뒤 ①데이터 정본 `dashboard_data.json` 과 ②데이터 내장형 단독 대시보드 `dashboard.html` 을 만든다. 그래프는 외부 차트 라이브러리 없이 인라인 SVG로 그리므로, 생성된 HTML 하나만으로 서버 없이 더블클릭만 해도 열린다. 모든 수치는 엑셀 실값에서 읽으며 임의값은 없다.

설계 원칙은 "틀은 고정, 데이터만 교체"다. 화면 틀(S18 HTML/CSS/JS)은 스크립트 하단 `_TEMPLATE_B64` 에 base64로 내장되어 있고, 매달 바뀌는 것은 입력 엑셀뿐이다. 실행 때 틀의 `%%DATA%%` 자리에 조립한 데이터를 주입한다.

---

## 동작 (한 번 실행에 4단계)

| 단계 | 하는 일 | 산출 |
|---|---|---|
| 1) 입력 이력 보관 | `raws\` · `outputs\analysis\` 의 모든 파일을 각 `log\YYYYMMDD_HHMMSS\` 로 복사 | 입력 스냅샷 |
| 2) 데이터 조립 | 엑셀 실값을 읽어 `DASHBOARD_DATA`(개요·검증·전망·예산·진단)로 정리 | `outputs\dashboard\dashboard_data.json` |
| 3) 화면 렌더 | 내장 틀(`%%DATA%%`)에 데이터를 주입해 단독 대시보드 생성 | `outputs\dashboard\dashboard.html` |
| 4) 산출 이력 보관 | `outputs\dashboard\` 의 파일을 `log\YYYYMMDD_HHMMSS\` 로 복사 | 산출 스냅샷 |

`log\` 폴더는 없으면 자동으로 만든다. 정본(항상 최신)은 `dashboard_data.json` 과 `dashboard.html` 두 개이고, `log\` 아래는 실행 시각별 이력이다.

---

## 입력 (이미 있는 데이터, 9개 파일)

| 파일 | 시트 | 용도 |
|---|---|---|
| `raws\customer_actuals_10yr.xlsx` | 월별 물류비 · 월별 물동량 · 월별 물동량 전망 | 실적 추이 · 물동 · 전망구간 평균 |
| `raws\customer_budget.xlsx` | Sheet1 | 연 예산(금액) |
| `raws\scfi_composite.xlsx` | 월별 SCFI | 운임(SCFI) 실적 |
| `raws\scfi_forecast_raw.xlsx` | 월별 SCFI 전망 | 운임 전망(슬라이더·시나리오 기준값) |
| `raws\ecos_fx_wti.xlsx` | 월별 환율 · 월별 WTI | 운임 민감도 외생회귀 변수 |
| `outputs\analysis\final_model_result.xlsx` | 최종예측 · 요약 | 추천모형 · 모델 전망(다중회귀·라쏘 등) |
| `outputs\analysis\model_results.xlsx` | 성능 / 다중회귀 / 라쏘 / 의사결정나무 | 모형 성능 · 모형별 실적 vs 예측 |
| `outputs\analysis\model_input_table.xlsx` | model_input | 운임 민감도 회귀 · 자기상관계수 |
| `outputs\analysis\diagnostics.xlsx` | LMG_포함 / LMG_제외 / 운임시차 / 계절효과 / 민감도 | 동인 기여도 · 시차 · 계절 · 민감도 |

`diagnostics.xlsx` 는 `make_diagnostics.py` 가, `model_input_table.xlsx`·`model_results.xlsx`·`final_model_result.xlsx` 는 모델 재학습 단계가 만든다(아래 "매달 갱신" 참고).

---

## 산출물

| 경로 | 내용 |
|---|---|
| `outputs\dashboard\dashboard_data.json` | 화면에 쓰인 숫자 정본(`DASHBOARD_DATA` 기록) |
| `outputs\dashboard\dashboard.html` | 데이터 내장형 단독 대시보드(더블클릭으로 열림) |
| `outputs\dashboard\log\YYYYMMDD_HHMMSS\` | 실행 시각별 산출 스냅샷 |
| `raws\log\...` · `outputs\analysis\log\...` | 실행 시각별 입력 스냅샷 |

---

## 대시보드 구성 (탭 5개)

- **개요**: 예산 경보, 이번 달 핵심 판단(3), 핵심 카드(다음 달 예측 · 운임 100p당 민감도 · 추천모형 정확도).
- **검증**: 세 모형 정확도 표(추천 모형 ★)와 모형별 실적 vs 예측 그래프(훈련·테스트 구간), 하단 시사점.
- **전망**: 모델 탭(다중회귀·라쏘), 실적·예측 라인과 ±6% 불확실성 밴드, 운임·물동량 슬라이더와 월 선택, 운임 충격 시나리오(±15%/±30%, 비관·기준·낙관).
- **예산**: 2026 누적 물류비 곡선과 예산선, 초과 지점, 월별 누적·소진율 표.
- **진단**: 동인 기여도(LMG 포함/제외) 막대, 운임 시차 효과, 자기상관계수, **월별 계절 효과**. 계절 효과는 diagnostics.xlsx [계절효과] 시트의 **(A) 원계절지수**(시계열 분해·연평균 기준·드라이버 무관 순수 계절성)를 읽어 표시한다. 그래프 아래 주석에 **산출 기간·산출식**(고전적 가법 분해: (실적−12개월 이동평균 추세)의 월별 평균, 연평균=0 정규화)·**월평균 기준선**과, **계절 비중이 전체 변동의 2%에 불과함**(운임 70%)을 함께 표시한다. LMG 막대에는 영문 풀네임(Lindeman·Merenda·Gold, Shapley 값 배분) 각주를 단다.

화주(매입) 관점을 전제로 하며, 운임(SCFI)은 화주가 지불하는 매입 원가로 서술한다.

---

## 실행 방법

`build_dashboard.py` 는 프로젝트 루트(`scfi_dashboard_basic\`)에 있다.

```
python build_dashboard.py
```

의존성은 `numpy` · `pandas` · `scikit-learn` · `openpyxl` 이다. S18 형태는 운임 민감도를 자기상관 제외 외생회귀(OLS·라쏘)로 계산하므로 `scikit-learn` 이 필요하다. `make_diagnostics.py` 를 돌리는 환경이면 그대로 실행된다.

---

## 매달 갱신

데이터가 매달 바뀌면 아래 순서로 상류부터 갱신한 뒤 이 스크립트를 실행한다.

> 순서: ① raws 갱신(별도 스크립트) → ② 모델 재학습(별도 스크립트 → `model_input_table.xlsx`·`model_results.xlsx`·`final_model_result.xlsx`) → ③ **make_diagnostics.py**(→ `diagnostics.xlsx`) → ④ **build_dashboard.py**(→ `dashboard_data.json`·`dashboard.html`)

> 의존 주의: ③ `make_diagnostics.py` 는 ②의 `model_input_table.xlsx` 를 읽고, ④ `build_dashboard.py` 는 ②·③의 산출을 모두 읽는다. 반드시 이 순서를 지킨다.

실행 직전 눈으로 확인하면 좋은 점검은 다음과 같다. 입력 9개 파일과 시트명이 그대로인지, `customer_actuals_10yr.xlsx` 의 마지막 실적 월이 이번 달까지 반영됐는지, `scfi_forecast_raw.xlsx` 전망 기간이 예측월과 맞는지, `customer_budget.xlsx` 의 연도·금액이 올해 값인지, `outputs\analysis\` 산출물의 수정 시각이 raws 갱신 **이후**인지.

---

## 유지보수 메모

- 화면 틀은 S18 동적 대시보드(S18_dynamic_dashboard)의 HTML/CSS/JS를 그대로 계승했고, 스크립트 하단 `_TEMPLATE_B64` 에 base64로 내장했다. **틀(디자인)을 바꾸려면**: 새 대시보드 HTML에서 데이터 블록(`window.DASHBOARD_DATA={…}`)을 `%%DATA%%` 로 바꾼 뒤 base64 인코딩해 `_TEMPLATE_B64` 를 교체한다.
- 운임 100p당 '한 달치 효과'는 자기상관(lag_cost) 제외 외생회귀에서 `lag_scfi` 1·2·3개월전 계수의 평균 ×100으로 계산한다(OLS·라쏘 병행). 진단 `민감도` 시트와 동일한 식별 논리다.
- 운임 ±15%/±30% 시나리오는 전망구간 평균 SCFI에 변동률을 적용해 비용을 평행이동(지속 충격)한 값이다.
- 해석 문구(개요 판단·검증 시사점·시나리오 대응·예산 액션·한계)는 코드가 숫자로 채우되 **사람이 검토하는 영역**이다.
- 추천 모형은 `final_model_result.xlsx` [요약]의 추천값을 따른다. 그래프는 외부 차트 라이브러리 없이 인라인 SVG로 그린다.
- 진단(LMG·시차·계절·민감도)은 `diagnostics.xlsx` 에서 **읽기만** 하며, 대시보드가 계산하지 않는다.
